<?xml version="1.0" encoding="utf-8"?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" version="1.0">
  <xsl:output doctype-public="-//W3C//DTD HTML 4.01 Transitional//EN" encoding="UTF-8" indent="no" method="html" version="4.01" />
  <xsl:decimal-format NaN="" />
  <xsl:decimal-format NaN="" minus-sign="▲" name="tri-min" />
  <xsl:template match="/">
    <xsl:apply-templates />
  </xsl:template>
  <xsl:template match="A-250075-007_1">
    <HTML lang="ja">
      <HEAD>
        <TITLE />
      </HEAD>
      <BODY style="color:rgb(0,0,0); background-color:rgb(255,255,255)">
        <FORM action="" method="POST">
          <DIV style="position:relative; left:0px; top:0px; width:785px; height:1120px;">
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:27px solid rgb(255, 255, 0); left:66px; top:1040px; width:369px; height:27px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; display:table; overflow:hidden; overflow-y:auto; color:rgb(0, 0, 0); background-color:rgb(255, 255, 0); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:66px; top:1040px; width:369px; height:27px; text-align:left; font-size:24px; font-family:'ＭＳ 明朝', serif;</xsl:attribute>
              <xsl:element name="SPAN">
                <xsl:attribute name="style">font-size:10px; height:10px; line-height:1em; vertical-align:top; display:table-cell; word-break:break-all; box-sizing:border-box;</xsl:attribute>
                <xsl:choose>
                  <xsl:when test="1">
                    <xsl:call-template name="adam-ins-br">
                      <xsl:with-param name="value" select="translate(備考欄[1]/備考[1]/text()[1], ' ','&#160;')" />
                    </xsl:call-template>
                  </xsl:when>
                </xsl:choose>
              </xsl:element>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:14px solid rgb(255, 255, 255); left:11px; top:3px; width:152px; height:14px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:11px; top:3px; width:152px; height:14px; text-align:left; font-size:11px; font-family:'ＭＳ ゴシック', sans-serif; padding:1px 0px 0px 0px;</xsl:attribute>第101条の30関係（第1面）</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:19px solid rgb(255, 255, 255); left:121px; top:19px; width:531px; height:19px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:121px; top:19px; width:531px; height:19px; text-align:center; font-size:16px; font-family:'ＭＳ ゴシック', sans-serif; padding:1px 0px 0px 0px;</xsl:attribute>育児休業給付受給資格確認票・（初回）育児休業給付金支給申請書</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:11px solid rgb(255, 255, 255); left:194px; top:38px; width:339px; height:11px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:194px; top:38px; width:339px; height:11px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>（必ず記載要領の注意書きをよく読んでから記入してください。）</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:11px solid rgb(255, 255, 255); left:35px; top:53px; width:43px; height:11px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:35px; top:53px; width:43px; height:11px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>帳票種別</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:11px solid rgb(255, 255, 255); left:156px; top:53px; width:80px; height:11px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:156px; top:53px; width:80px; height:11px; text-align:left; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>１被保険者番号</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:23px solid rgb(255, 255, 255); left:234px; top:64px; width:26px; height:23px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:234px; top:64px; width:26px; height:23px; text-align:center; font-size:14px; font-family:'ＭＳ ゴシック', sans-serif; padding:3px 0px 0px 0px;</xsl:attribute>―</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:23px solid rgb(255, 255, 255); left:379px; top:64px; width:26px; height:23px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:379px; top:64px; width:26px; height:23px; text-align:center; font-size:14px; font-family:'ＭＳ ゴシック', sans-serif; padding:3px 0px 0px 0px;</xsl:attribute>―</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:11px solid rgb(255, 255, 255); left:508px; top:53px; width:95px; height:11px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:508px; top:53px; width:95px; height:11px; text-align:left; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>２資格取得年月日</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:11px solid rgb(255, 255, 255); left:594px; top:72px; width:11px; height:11px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:594px; top:72px; width:11px; height:11px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>年</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:11px solid rgb(255, 255, 255); left:651px; top:72px; width:11px; height:11px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:651px; top:72px; width:11px; height:11px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>月</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:11px solid rgb(255, 255, 255); left:708px; top:72px; width:12px; height:11px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:708px; top:72px; width:12px; height:11px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>日</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:11px solid rgb(255, 255, 255); left:11px; top:95px; width:87px; height:11px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:11px; top:95px; width:87px; height:11px; text-align:left; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>３被保険者氏名</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:11px solid rgb(255, 255, 255); left:340px; top:95px; width:108px; height:11px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:340px; top:95px; width:108px; height:11px; text-align:left; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>フリガナ（カタカナ）</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:11px solid rgb(255, 255, 255); left:11px; top:137px; width:69px; height:11px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:11px; top:137px; width:69px; height:11px; text-align:left; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>４事業所番号</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:23px solid rgb(255, 255, 255); left:89px; top:150px; width:27px; height:23px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:89px; top:150px; width:27px; height:23px; text-align:center; font-size:14px; font-family:'ＭＳ ゴシック', sans-serif; padding:3px 0px 0px 0px;</xsl:attribute>―</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:23px solid rgb(255, 255, 255); left:234px; top:150px; width:26px; height:23px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:234px; top:150px; width:26px; height:23px; text-align:center; font-size:14px; font-family:'ＭＳ ゴシック', sans-serif; padding:3px 0px 0px 0px;</xsl:attribute>―</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:11px solid rgb(255, 255, 255); left:319px; top:137px; width:115px; height:11px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:319px; top:137px; width:115px; height:11px; text-align:left; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>５育児休業開始年月日</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:11px solid rgb(255, 255, 255); left:405px; top:158px; width:12px; height:11px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:405px; top:158px; width:12px; height:11px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>年</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:11px solid rgb(255, 255, 255); left:462px; top:158px; width:12px; height:11px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:462px; top:158px; width:12px; height:11px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>月</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:11px solid rgb(255, 255, 255); left:520px; top:158px; width:11px; height:11px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:520px; top:158px; width:11px; height:11px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>日</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:11px solid rgb(255, 255, 255); left:544px; top:137px; width:68px; height:11px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:544px; top:137px; width:68px; height:11px; text-align:left; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>６出産年月日</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:11px solid rgb(255, 255, 255); left:630px; top:158px; width:12px; height:11px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:630px; top:158px; width:12px; height:11px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>年</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:11px solid rgb(255, 255, 255); left:687px; top:158px; width:12px; height:11px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:687px; top:158px; width:12px; height:11px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>月</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:11px solid rgb(255, 255, 255); left:744px; top:158px; width:12px; height:11px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:744px; top:158px; width:12px; height:11px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>日</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:11px solid rgb(255, 255, 255); left:544px; top:179px; width:68px; height:11px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:544px; top:179px; width:68px; height:11px; text-align:left; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>７出産予定日</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:11px solid rgb(255, 255, 255); left:630px; top:200px; width:12px; height:11px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:630px; top:200px; width:12px; height:11px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>年</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:11px solid rgb(255, 255, 255); left:687px; top:200px; width:12px; height:11px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:687px; top:200px; width:12px; height:11px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>月</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:11px solid rgb(255, 255, 255); left:744px; top:200px; width:12px; height:11px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:744px; top:200px; width:12px; height:11px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>日</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:11px solid rgb(255, 255, 255); left:11px; top:179px; width:129px; height:11px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:11px; top:179px; width:129px; height:11px; text-align:left; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>８過去に同一の子について</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:11px solid rgb(255, 255, 255); left:11px; top:190px; width:118px; height:11px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:11px; top:190px; width:118px; height:11px; text-align:left; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>　出生時育児休業または</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:12px solid rgb(255, 255, 255); left:11px; top:201px; width:118px; height:12px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:11px; top:201px; width:118px; height:12px; text-align:left; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>　育児休業取得の有無</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:11px solid rgb(255, 255, 255); left:240px; top:179px; width:60px; height:11px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:240px; top:179px; width:60px; height:11px; text-align:left; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>９個人番号</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:12px solid rgb(255, 255, 255); left:11px; top:220px; width:160px; height:12px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:11px; top:220px; width:160px; height:12px; text-align:left; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>10被保険者の住所（郵便番号）</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:23px solid rgb(255, 255, 255); left:56px; top:234px; width:23px; height:23px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:56px; top:234px; width:23px; height:23px; text-align:center; font-size:14px; font-family:'ＭＳ ゴシック', sans-serif; padding:3px 0px 0px 0px;</xsl:attribute>―</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:12px solid rgb(255, 255, 255); left:11px; top:262px; width:263px; height:12px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:11px; top:262px; width:263px; height:12px; text-align:left; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>11被保険者の住所（漢字）※市・区・郡及び町村名</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:12px solid rgb(255, 255, 255); left:20px; top:304px; width:194px; height:12px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:20px; top:304px; width:194px; height:12px; text-align:left; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>被保険者の住所（漢字）※丁目・番地</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:12px solid rgb(255, 255, 255); left:20px; top:346px; width:274px; height:12px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:20px; top:346px; width:274px; height:12px; text-align:left; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>被保険者の住所（漢字）※アパート、マンション名等</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:12px solid rgb(255, 255, 255); left:339px; top:220px; width:114px; height:12px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:339px; top:220px; width:114px; height:12px; text-align:left; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>12被保険者の電話番号</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:23px solid rgb(255, 255, 255); left:417px; top:234px; width:23px; height:23px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:417px; top:234px; width:23px; height:23px; text-align:center; font-size:14px; font-family:'ＭＳ ゴシック', sans-serif; padding:3px 0px 0px 0px;</xsl:attribute>―</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:23px solid rgb(255, 255, 255); left:520px; top:234px; width:22px; height:23px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:520px; top:234px; width:22px; height:23px; text-align:center; font-size:14px; font-family:'ＭＳ ゴシック', sans-serif; padding:3px 0px 0px 0px;</xsl:attribute>―</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:12px solid rgb(255, 255, 255); left:11px; top:388px; width:194px; height:12px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:11px; top:388px; width:194px; height:12px; text-align:left; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>13支給単位期間その１（初日－末日）</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:12px solid rgb(255, 255, 255); left:95px; top:409px; width:11px; height:12px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:95px; top:409px; width:11px; height:12px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>年</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:12px solid rgb(255, 255, 255); left:148px; top:409px; width:12px; height:12px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:148px; top:409px; width:12px; height:12px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>月</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:12px solid rgb(255, 255, 255); left:201px; top:409px; width:12px; height:12px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:201px; top:409px; width:12px; height:12px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>日</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:23px solid rgb(255, 255, 255); left:215px; top:401px; width:23px; height:23px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:215px; top:401px; width:23px; height:23px; text-align:center; font-size:14px; font-family:'ＭＳ ゴシック', sans-serif; padding:3px 0px 0px 0px;</xsl:attribute>―</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:12px solid rgb(255, 255, 255); left:280px; top:409px; width:11px; height:12px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:280px; top:409px; width:11px; height:12px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>月</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:12px solid rgb(255, 255, 255); left:333px; top:409px; width:11px; height:12px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:333px; top:409px; width:11px; height:12px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>日</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:12px solid rgb(255, 255, 255); left:385px; top:388px; width:61px; height:12px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:385px; top:388px; width:61px; height:12px; text-align:left; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>14就業日数</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:12px solid rgb(255, 255, 255); left:427px; top:409px; width:12px; height:12px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:427px; top:409px; width:12px; height:12px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>日</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:12px solid rgb(255, 255, 255); left:488px; top:388px; width:61px; height:12px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:488px; top:388px; width:61px; height:12px; text-align:left; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>15就業時間</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:12px solid rgb(255, 255, 255); left:530px; top:409px; width:23px; height:12px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:530px; top:409px; width:23px; height:12px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>時間</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:12px solid rgb(255, 255, 255); left:595px; top:388px; width:107px; height:12px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:595px; top:388px; width:107px; height:12px; text-align:left; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>16支払われた賃金額</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:12px solid rgb(255, 255, 255); left:732px; top:409px; width:12px; height:12px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:732px; top:409px; width:12px; height:12px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>円</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:11px solid rgb(255, 255, 255); left:11px; top:430px; width:194px; height:11px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:11px; top:430px; width:194px; height:11px; text-align:left; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>17支給単位期間その２（初日－末日）</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:11px solid rgb(255, 255, 255); left:95px; top:451px; width:11px; height:11px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:95px; top:451px; width:11px; height:11px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>年</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:11px solid rgb(255, 255, 255); left:148px; top:451px; width:12px; height:11px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:148px; top:451px; width:12px; height:11px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>月</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:11px solid rgb(255, 255, 255); left:201px; top:451px; width:12px; height:11px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:201px; top:451px; width:12px; height:11px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>日</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:23px solid rgb(255, 255, 255); left:215px; top:443px; width:23px; height:23px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:215px; top:443px; width:23px; height:23px; text-align:center; font-size:14px; font-family:'ＭＳ ゴシック', sans-serif; padding:3px 0px 0px 0px;</xsl:attribute>―</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:11px solid rgb(255, 255, 255); left:280px; top:451px; width:11px; height:11px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:280px; top:451px; width:11px; height:11px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>月</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:11px solid rgb(255, 255, 255); left:333px; top:451px; width:11px; height:11px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:333px; top:451px; width:11px; height:11px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>日</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:11px solid rgb(255, 255, 255); left:385px; top:430px; width:61px; height:11px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:385px; top:430px; width:61px; height:11px; text-align:left; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>18就業日数</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:11px solid rgb(255, 255, 255); left:427px; top:451px; width:12px; height:11px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:427px; top:451px; width:12px; height:11px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>日</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:11px solid rgb(255, 255, 255); left:488px; top:430px; width:61px; height:11px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:488px; top:430px; width:61px; height:11px; text-align:left; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>19就業時間</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:11px solid rgb(255, 255, 255); left:530px; top:451px; width:23px; height:11px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:530px; top:451px; width:23px; height:11px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>時間</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:11px solid rgb(255, 255, 255); left:595px; top:430px; width:107px; height:11px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:595px; top:430px; width:107px; height:11px; text-align:left; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>20支払われた賃金額</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:11px solid rgb(255, 255, 255); left:732px; top:451px; width:12px; height:11px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:732px; top:451px; width:12px; height:11px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>円</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:11px solid rgb(255, 255, 255); left:11px; top:472px; width:194px; height:11px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:11px; top:472px; width:194px; height:11px; text-align:left; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>21最終支給単位期間（初日－末日）</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:11px solid rgb(255, 255, 255); left:95px; top:493px; width:11px; height:11px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:95px; top:493px; width:11px; height:11px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>年</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:11px solid rgb(255, 255, 255); left:148px; top:493px; width:12px; height:11px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:148px; top:493px; width:12px; height:11px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>月</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:11px solid rgb(255, 255, 255); left:201px; top:493px; width:12px; height:11px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:201px; top:493px; width:12px; height:11px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>日</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:23px solid rgb(255, 255, 255); left:215px; top:485px; width:23px; height:23px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:215px; top:485px; width:23px; height:23px; text-align:center; font-size:14px; font-family:'ＭＳ ゴシック', sans-serif; padding:3px 0px 0px 0px;</xsl:attribute>―</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:11px solid rgb(255, 255, 255); left:280px; top:493px; width:11px; height:11px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:280px; top:493px; width:11px; height:11px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>月</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:11px solid rgb(255, 255, 255); left:333px; top:493px; width:11px; height:11px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:333px; top:493px; width:11px; height:11px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>日</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:11px solid rgb(255, 255, 255); left:385px; top:472px; width:61px; height:11px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:385px; top:472px; width:61px; height:11px; text-align:left; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>22就業日数</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:11px solid rgb(255, 255, 255); left:427px; top:493px; width:12px; height:11px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:427px; top:493px; width:12px; height:11px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>日</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:11px solid rgb(255, 255, 255); left:488px; top:472px; width:61px; height:11px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:488px; top:472px; width:61px; height:11px; text-align:left; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>23就業時間</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:11px solid rgb(255, 255, 255); left:530px; top:493px; width:23px; height:11px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:530px; top:493px; width:23px; height:11px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>時間</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:11px solid rgb(255, 255, 255); left:595px; top:472px; width:107px; height:11px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:595px; top:472px; width:107px; height:11px; text-align:left; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>24支払われた賃金額</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:11px solid rgb(255, 255, 255); left:732px; top:493px; width:12px; height:11px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:732px; top:493px; width:12px; height:11px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>円</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:11px solid rgb(255, 255, 255); left:11px; top:514px; width:99px; height:11px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:11px; top:514px; width:99px; height:11px; text-align:left; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>25職場復帰年月日</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:11px solid rgb(255, 255, 255); left:87px; top:535px; width:12px; height:11px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:87px; top:535px; width:12px; height:11px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>年</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:11px solid rgb(255, 255, 255); left:133px; top:535px; width:11px; height:11px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:133px; top:535px; width:11px; height:11px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>月</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:11px solid rgb(255, 255, 255); left:177px; top:535px; width:11px; height:11px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:177px; top:535px; width:11px; height:11px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>日</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:11px solid rgb(255, 255, 255); left:209px; top:514px; width:202px; height:11px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:209px; top:514px; width:202px; height:11px; text-align:left; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>26支給対象となる期間の延長事由－期間</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:23px solid rgb(255, 255, 255); left:234px; top:527px; width:19px; height:23px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:234px; top:527px; width:19px; height:23px; text-align:center; font-size:14px; font-family:'ＭＳ ゴシック', sans-serif; padding:3px 0px 0px 0px;</xsl:attribute>―</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:11px solid rgb(255, 255, 255); left:336px; top:535px; width:12px; height:11px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:336px; top:535px; width:12px; height:11px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>年</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:11px solid rgb(255, 255, 255); left:383px; top:535px; width:12px; height:11px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:383px; top:535px; width:12px; height:11px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>月</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:11px solid rgb(255, 255, 255); left:430px; top:535px; width:11px; height:11px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:430px; top:535px; width:11px; height:11px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>日</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:23px solid rgb(255, 255, 255); left:446px; top:527px; width:19px; height:23px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:446px; top:527px; width:19px; height:23px; text-align:center; font-size:14px; font-family:'ＭＳ ゴシック', sans-serif; padding:3px 0px 0px 0px;</xsl:attribute>―</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:11px solid rgb(255, 255, 255); left:503px; top:535px; width:12px; height:11px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:503px; top:535px; width:12px; height:11px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>月</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:11px solid rgb(255, 255, 255); left:550px; top:535px; width:12px; height:11px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:550px; top:535px; width:12px; height:11px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>日</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:46px solid rgb(255, 255, 255); left:565px; top:512px; width:8px; height:46px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:565px; top:512px; width:8px; height:46px; text-align:left; font-size:13px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:40px solid rgb(255, 255, 255); left:567px; top:515px; width:4px; height:40px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); border-top:1px solid rgb(0, 0, 0); border-right:0px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:567px; top:515px; width:4px; height:40px; text-align:left; font-size:13px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:8px solid rgb(255, 255, 255); left:578px; top:512px; width:139px; height:8px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:578px; top:512px; width:139px; height:8px; text-align:left; font-size:6px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>1<xsl:call-template name="adam-nbsp" />保育所における保育が実施されないこと</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:7px solid rgb(255, 255, 255); left:578px; top:520px; width:120px; height:8px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:578px; top:520px; width:120px; height:8px; text-align:left; font-size:6px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>2<xsl:call-template name="adam-nbsp" />養育を予定していた配偶者の死亡</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:8px solid rgb(255, 255, 255); left:578px; top:528px; width:142px; height:8px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:578px; top:528px; width:142px; height:8px; text-align:left; font-size:6px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>3<xsl:call-template name="adam-nbsp" />養育を予定していた配偶者の負傷・疾病等</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:7px solid rgb(255, 255, 255); left:578px; top:536px; width:159px; height:8px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:578px; top:536px; width:159px; height:8px; text-align:left; font-size:6px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>4<xsl:call-template name="adam-nbsp" />養育を予定していた配偶者との婚姻の解消等による別居</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:8px solid rgb(255, 255, 255); left:578px; top:544px; width:147px; height:8px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:578px; top:544px; width:147px; height:8px; text-align:left; font-size:6px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>5<xsl:call-template name="adam-nbsp" />養育を予定していた配偶者の産前産後休業等</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:8px solid rgb(255, 255, 255); left:578px; top:552px; width:147px; height:8px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:578px; top:552px; width:147px; height:8px; text-align:left; font-size:6px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>6<xsl:call-template name="adam-nbsp" />他休業事由の消滅</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:46px solid rgb(255, 255, 255); left:742px; top:512px; width:8px; height:46px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:742px; top:512px; width:8px; height:46px; text-align:left; font-size:13px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:40px solid rgb(255, 255, 255); left:744px; top:515px; width:4px; height:40px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); left:744px; top:515px; width:4px; height:40px; text-align:left; font-size:13px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:1px dashed rgb(0, 0, 0); left:37px; top:601px; width:523px; line-height:0px; height:0px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:1px dashed rgb(0, 0, 0); left:559px; top:560px; width:224px; line-height:0px; height:0px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-left:1px dashed rgb(0, 0, 0); left:559px; top:560px; width:1px; height:41px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:1px dashed rgb(0, 0, 0); left:37px; top:731px; width:745px; line-height:0px; height:0px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-left:1px dashed rgb(0, 0, 0); left:782px; top:560px; width:1px; height:171px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:11px solid rgb(255, 255, 255); left:11px; top:556px; width:88px; height:11px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:11px; top:556px; width:88px; height:11px; text-align:left; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>27配偶者育休取得</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:11px solid rgb(255, 255, 255); left:106px; top:556px; width:130px; height:11px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:106px; top:556px; width:130px; height:11px; text-align:left; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>28配偶者の被保険者番号</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:23px solid rgb(255, 255, 255); left:184px; top:569px; width:27px; height:23px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:184px; top:569px; width:27px; height:23px; text-align:center; font-size:14px; font-family:'ＭＳ ゴシック', sans-serif; padding:3px 0px 0px 0px;</xsl:attribute>―</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:23px solid rgb(255, 255, 255); left:329px; top:569px; width:27px; height:23px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:329px; top:569px; width:27px; height:23px; text-align:center; font-size:14px; font-family:'ＭＳ ゴシック', sans-serif; padding:3px 0px 0px 0px;</xsl:attribute>―</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:11px solid rgb(255, 255, 255); left:396px; top:556px; width:110px; height:11px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:396px; top:556px; width:110px; height:11px; text-align:left; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>29育児休業再取得理由</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:31px solid rgb(255, 255, 255); left:421px; top:567px; width:8px; height:31px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:421px; top:567px; width:8px; height:31px; text-align:left; font-size:13px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:27px solid rgb(255, 255, 255); left:423px; top:569px; width:4px; height:27px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); border-top:1px solid rgb(0, 0, 0); border-right:0px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:423px; top:569px; width:4px; height:27px; text-align:left; font-size:13px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:8px solid rgb(255, 255, 255); left:434px; top:567px; width:68px; height:8px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:434px; top:567px; width:68px; height:8px; text-align:left; font-size:6px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>1<xsl:call-template name="adam-nbsp" />他休業事由の消滅</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:7px solid rgb(255, 255, 255); left:434px; top:575px; width:68px; height:8px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:434px; top:575px; width:68px; height:8px; text-align:left; font-size:6px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>2<xsl:call-template name="adam-nbsp" />配偶者等の事由</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:8px solid rgb(255, 255, 255); left:434px; top:583px; width:68px; height:8px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:434px; top:583px; width:68px; height:8px; text-align:left; font-size:6px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>3<xsl:call-template name="adam-nbsp" />子や保育の事情</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:8px solid rgb(255, 255, 255); left:434px; top:591px; width:68px; height:8px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:434px; top:591px; width:68px; height:8px; text-align:left; font-size:6px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>5<xsl:call-template name="adam-nbsp" />延長交替</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:31px solid rgb(255, 255, 255); left:507px; top:567px; width:8px; height:31px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:507px; top:567px; width:8px; height:31px; text-align:left; font-size:13px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:27px solid rgb(255, 255, 255); left:509px; top:569px; width:4px; height:27px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); left:509px; top:569px; width:4px; height:27px; text-align:left; font-size:13px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:131px solid rgb(255, 255, 255); left:11px; top:601px; width:25px; height:131px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); border-top:1px dashed rgb(0, 0, 0); border-right:1px dashed rgb(0, 0, 0); border-bottom:1px dashed rgb(0, 0, 0); border-left:1px dashed rgb(0, 0, 0); left:11px; top:601px; width:25px; height:131px; text-align:left; font-size:14px; font-family:'ＭＳ 明朝', serif; padding:113px 0px 0px 0px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:12px solid rgb(255, 255, 255); left:16px; top:603px; width:14px; height:12px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:16px; top:603px; width:14px; height:12px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif; padding:2px 0px 0px 0px;</xsl:attribute>※</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:11px solid rgb(255, 255, 255); left:16px; top:615px; width:14px; height:11px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:16px; top:615px; width:14px; height:11px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif; padding:1px 0px 0px 0px;</xsl:attribute>公</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:12px solid rgb(255, 255, 255); left:16px; top:626px; width:14px; height:12px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:16px; top:626px; width:14px; height:12px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif; padding:1px 0px 0px 0px;</xsl:attribute>共</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:11px solid rgb(255, 255, 255); left:16px; top:638px; width:14px; height:11px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:16px; top:638px; width:14px; height:11px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif; padding:1px 0px 0px 0px;</xsl:attribute>職</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:12px solid rgb(255, 255, 255); left:16px; top:649px; width:14px; height:12px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:16px; top:649px; width:14px; height:12px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif; padding:2px 0px 0px 0px;</xsl:attribute>業</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:11px solid rgb(255, 255, 255); left:16px; top:661px; width:14px; height:11px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:16px; top:661px; width:14px; height:11px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif; padding:1px 0px 0px 0px;</xsl:attribute>安</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:11px solid rgb(255, 255, 255); left:16px; top:672px; width:14px; height:11px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:16px; top:672px; width:14px; height:11px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif; padding:1px 0px 0px 0px;</xsl:attribute>定</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:12px solid rgb(255, 255, 255); left:16px; top:683px; width:14px; height:12px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:16px; top:683px; width:14px; height:12px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif; padding:2px 0px 0px 0px;</xsl:attribute>所</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:11px solid rgb(255, 255, 255); left:16px; top:695px; width:14px; height:11px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:16px; top:695px; width:14px; height:11px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif; padding:1px 0px 0px 0px;</xsl:attribute>記</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:12px solid rgb(255, 255, 255); left:16px; top:706px; width:14px; height:12px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:16px; top:706px; width:14px; height:12px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif; padding:1px 0px 0px 0px;</xsl:attribute>載</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:11px solid rgb(255, 255, 255); left:16px; top:718px; width:14px; height:11px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:16px; top:718px; width:14px; height:11px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif; padding:1px 0px 0px 0px;</xsl:attribute>欄</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:12px solid rgb(255, 255, 255); left:41px; top:605px; width:77px; height:12px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:41px; top:605px; width:77px; height:12px; text-align:left; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>30期間雇用者の</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:11px solid rgb(255, 255, 255); left:41px; top:617px; width:58px; height:11px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:41px; top:617px; width:58px; height:11px; text-align:left; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>　継続雇用</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:12px solid rgb(255, 255, 255); left:41px; top:628px; width:58px; height:12px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:41px; top:628px; width:58px; height:12px; text-align:left; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>　の見込み</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:12px solid rgb(255, 255, 255); left:129px; top:605px; width:46px; height:12px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:129px; top:605px; width:46px; height:12px; text-align:left; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>32延長等</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:11px solid rgb(255, 255, 255); left:129px; top:617px; width:35px; height:11px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:129px; top:617px; width:35px; height:11px; text-align:left; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>　否認</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:12px solid rgb(255, 255, 255); left:200px; top:605px; width:76px; height:12px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:200px; top:605px; width:76px; height:12px; text-align:left; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>33産後休業表示</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:26px solid rgb(255, 255, 255); left:225px; top:619px; width:8px; height:26px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:225px; top:619px; width:8px; height:26px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif; padding:7px 0px 0px 0px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:22px solid rgb(255, 255, 255); left:227px; top:622px; width:4px; height:22px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); border-top:1px solid rgb(0, 0, 0); border-right:0px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:227px; top:622px; width:4px; height:22px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif; padding:4px 0px 0px 0px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:9px solid rgb(255, 255, 255); left:238px; top:617px; width:50px; height:9px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:238px; top:617px; width:50px; height:9px; text-align:left; font-size:8px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>休業がある</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:10px solid rgb(255, 255, 255); left:238px; top:626px; width:46px; height:10px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:238px; top:626px; width:46px; height:10px; text-align:left; font-size:8px; font-family:'ＭＳ ゴシック', sans-serif; padding:1px 0px 0px 0px;</xsl:attribute>場合に「1」</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:9px solid rgb(255, 255, 255); left:238px; top:636px; width:38px; height:9px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:238px; top:636px; width:38px; height:9px; text-align:left; font-size:8px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>を記入</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:26px solid rgb(255, 255, 255); left:289px; top:619px; width:8px; height:26px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:289px; top:619px; width:8px; height:26px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif; padding:7px 0px 0px 0px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:22px solid rgb(255, 255, 255); left:291px; top:622px; width:4px; height:22px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); left:291px; top:622px; width:4px; height:22px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif; padding:4px 0px 0px 0px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:12px solid rgb(255, 255, 255); left:308px; top:605px; width:194px; height:12px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:308px; top:605px; width:194px; height:12px; text-align:left; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>34賃金月額（区分－日額又は総額）</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:22px solid rgb(255, 255, 255); left:333px; top:619px; width:23px; height:22px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:333px; top:619px; width:23px; height:22px; text-align:center; font-size:14px; font-family:'ＭＳ ゴシック', sans-serif; padding:3px 0px 0px 0px;</xsl:attribute>―</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:12px solid rgb(255, 255, 255); left:516px; top:626px; width:12px; height:12px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:516px; top:626px; width:12px; height:12px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>円</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:26px solid rgb(255, 255, 255); left:533px; top:619px; width:8px; height:26px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:533px; top:619px; width:8px; height:26px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif; padding:7px 0px 0px 0px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:19px solid rgb(255, 255, 255); left:535px; top:623px; width:4px; height:19px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); border-top:1px solid rgb(0, 0, 0); border-right:0px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:535px; top:623px; width:4px; height:19px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif; padding:2px 0px 0px 0px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:11px solid rgb(255, 255, 255); left:544px; top:623px; width:31px; height:11px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:544px; top:623px; width:31px; height:11px; text-align:center; font-size:8px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>1<xsl:call-template name="adam-nbsp" />日額</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:11px solid rgb(255, 255, 255); left:544px; top:634px; width:31px; height:11px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:544px; top:634px; width:31px; height:11px; text-align:center; font-size:8px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>2<xsl:call-template name="adam-nbsp" />総額</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:26px solid rgb(255, 255, 255); left:582px; top:619px; width:8px; height:26px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:582px; top:619px; width:8px; height:26px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif; padding:7px 0px 0px 0px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:19px solid rgb(255, 255, 255); left:580px; top:623px; width:4px; height:19px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); left:580px; top:623px; width:4px; height:19px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif; padding:2px 0px 0px 0px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:12px solid rgb(255, 255, 255); left:592px; top:563px; width:129px; height:12px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:592px; top:563px; width:129px; height:12px; text-align:left; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>31休業事由の消滅年月日</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:15px solid rgb(255, 255, 255); left:669px; top:581px; width:12px; height:15px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:669px; top:581px; width:12px; height:15px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif; padding:1px 0px 0px 0px;</xsl:attribute>年</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:15px solid rgb(255, 255, 255); left:716px; top:581px; width:12px; height:15px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:716px; top:581px; width:12px; height:15px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif; padding:1px 0px 0px 0px;</xsl:attribute>月</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:15px solid rgb(255, 255, 255); left:763px; top:581px; width:11px; height:15px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:763px; top:581px; width:11px; height:15px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif; padding:1px 0px 0px 0px;</xsl:attribute>日</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:12px solid rgb(255, 255, 255); left:592px; top:605px; width:160px; height:12px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:592px; top:605px; width:160px; height:12px; text-align:left; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>35当初の育児休業開始年月日</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:12px solid rgb(255, 255, 255); left:669px; top:626px; width:12px; height:12px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:669px; top:626px; width:12px; height:12px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>年</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:12px solid rgb(255, 255, 255); left:716px; top:626px; width:12px; height:12px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:716px; top:626px; width:12px; height:12px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>月</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:12px solid rgb(255, 255, 255); left:763px; top:626px; width:11px; height:12px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:763px; top:626px; width:11px; height:12px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>日</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:12px solid rgb(255, 255, 255); left:41px; top:647px; width:126px; height:12px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:41px; top:647px; width:126px; height:12px; text-align:left; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>36受給資格確認年月日</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:12px solid rgb(255, 255, 255); left:118px; top:668px; width:11px; height:12px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:118px; top:668px; width:11px; height:12px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>年</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:12px solid rgb(255, 255, 255); left:165px; top:668px; width:12px; height:12px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:165px; top:668px; width:12px; height:12px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>月</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:12px solid rgb(255, 255, 255); left:212px; top:668px; width:12px; height:12px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:212px; top:668px; width:12px; height:12px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>日</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:12px solid rgb(255, 255, 255); left:289px; top:647px; width:88px; height:12px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:289px; top:647px; width:88px; height:12px; text-align:left; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>37受給資格否認</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:26px solid rgb(255, 255, 255); left:314px; top:661px; width:8px; height:26px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:314px; top:661px; width:8px; height:26px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif; padding:7px 0px 0px 0px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:19px solid rgb(255, 255, 255); left:316px; top:665px; width:4px; height:19px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); border-top:1px solid rgb(0, 0, 0); border-right:0px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:316px; top:665px; width:4px; height:19px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif; padding:2px 0px 0px 0px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:11px solid rgb(255, 255, 255); left:327px; top:665px; width:106px; height:11px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:327px; top:665px; width:106px; height:11px; text-align:center; font-size:8px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>受給資格なしと判断した</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:11px solid rgb(255, 255, 255); left:328px; top:676px; width:83px; height:11px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:328px; top:676px; width:83px; height:11px; text-align:center; font-size:8px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>場合に「1」を記入</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:26px solid rgb(255, 255, 255); left:439px; top:661px; width:8px; height:26px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:439px; top:661px; width:8px; height:26px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif; padding:7px 0px 0px 0px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:19px solid rgb(255, 255, 255); left:441px; top:665px; width:4px; height:19px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); left:441px; top:665px; width:4px; height:19px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif; padding:2px 0px 0px 0px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:12px solid rgb(255, 255, 255); left:468px; top:647px; width:80px; height:12px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:468px; top:647px; width:80px; height:12px; text-align:left; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>38支給申請月</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:26px solid rgb(255, 255, 255); left:493px; top:661px; width:8px; height:26px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:493px; top:661px; width:8px; height:26px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif; padding:7px 0px 0px 0px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:19px solid rgb(255, 255, 255); left:495px; top:665px; width:4px; height:19px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); border-top:1px solid rgb(0, 0, 0); border-right:0px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:495px; top:665px; width:4px; height:19px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif; padding:2px 0px 0px 0px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:11px solid rgb(255, 255, 255); left:506px; top:665px; width:38px; height:11px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:506px; top:665px; width:38px; height:11px; text-align:center; font-size:8px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>1<xsl:call-template name="adam-nbsp" />奇数月</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:11px solid rgb(255, 255, 255); left:506px; top:676px; width:38px; height:11px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:506px; top:676px; width:38px; height:11px; text-align:center; font-size:8px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>2<xsl:call-template name="adam-nbsp" />偶数月</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:26px solid rgb(255, 255, 255); left:549px; top:661px; width:8px; height:26px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:549px; top:661px; width:8px; height:26px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif; padding:7px 0px 0px 0px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:19px solid rgb(255, 255, 255); left:551px; top:665px; width:4px; height:19px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); left:551px; top:665px; width:4px; height:19px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif; padding:2px 0px 0px 0px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:12px solid rgb(255, 255, 255); left:592px; top:647px; width:126px; height:12px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:592px; top:647px; width:126px; height:12px; text-align:left; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>39次回支給申請年月日</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:12px solid rgb(255, 255, 255); left:669px; top:668px; width:12px; height:12px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:669px; top:668px; width:12px; height:12px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>年</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:12px solid rgb(255, 255, 255); left:716px; top:668px; width:12px; height:12px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:716px; top:668px; width:12px; height:12px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>月</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:12px solid rgb(255, 255, 255); left:763px; top:668px; width:11px; height:12px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:763px; top:668px; width:11px; height:12px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>日</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:12px solid rgb(255, 255, 255); left:41px; top:689px; width:69px; height:12px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:41px; top:689px; width:69px; height:12px; text-align:left; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>40支払区分</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:12px solid rgb(255, 255, 255); left:140px; top:689px; width:138px; height:12px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:140px; top:689px; width:138px; height:12px; text-align:left; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>41金融機関・店舗コード</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:22px solid rgb(255, 255, 255); left:275px; top:701px; width:23px; height:22px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:275px; top:701px; width:23px; height:22px; text-align:center; font-size:14px; font-family:'ＭＳ ゴシック', sans-serif; padding:5px 0px 0px 0px;</xsl:attribute>―</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:12px solid rgb(255, 255, 255); left:300px; top:689px; width:46px; height:12px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:300px; top:689px; width:46px; height:12px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>口座番号</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:12px solid rgb(255, 255, 255); left:592px; top:689px; width:80px; height:12px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:592px; top:689px; width:80px; height:12px; text-align:left; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>42未支給区分</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:27px solid rgb(255, 255, 255); left:617px; top:702px; width:8px; height:27px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:617px; top:702px; width:8px; height:27px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif; padding:7px 0px 0px 0px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:19px solid rgb(255, 255, 255); left:619px; top:707px; width:4px; height:19px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); border-top:1px solid rgb(0, 0, 0); border-right:0px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:619px; top:707px; width:4px; height:19px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif; padding:2px 0px 0px 0px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:12px solid rgb(255, 255, 255); left:630px; top:706px; width:76px; height:12px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:630px; top:706px; width:76px; height:12px; text-align:center; font-size:8px; font-family:'ＭＳ ゴシック', sans-serif; padding:1px 0px 0px 0px;</xsl:attribute>空欄<xsl:call-template name="adam-nbsp" />未支給以外</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:11px solid rgb(255, 255, 255); left:640px; top:718px; width:45px; height:11px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:640px; top:718px; width:45px; height:11px; text-align:center; font-size:8px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>1<xsl:call-template name="adam-nbsp" />未支給</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:27px solid rgb(255, 255, 255); left:711px; top:702px; width:8px; height:27px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:711px; top:702px; width:8px; height:27px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif; padding:7px 0px 0px 0px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:19px solid rgb(255, 255, 255); left:713px; top:707px; width:4px; height:19px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); left:713px; top:707px; width:4px; height:19px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif; padding:2px 0px 0px 0px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:93px solid rgb(255, 255, 255); left:49px; top:735px; width:685px; height:93px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:49px; top:735px; width:685px; height:93px; text-align:left; font-size:14px; font-family:'ＭＳ 明朝', serif; padding:75px 0px 0px 0px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:11px solid rgb(255, 255, 255); left:53px; top:739px; width:419px; height:11px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:53px; top:739px; width:419px; height:11px; text-align:left; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>上記被保険者が育児休業を取得し、上記の記載事実に誤りがないことを証明します。</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:12px solid rgb(255, 255, 255); left:137px; top:811px; width:11px; height:12px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:137px; top:811px; width:11px; height:12px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>年</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:12px solid rgb(255, 255, 255); left:179px; top:811px; width:11px; height:12px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:179px; top:811px; width:11px; height:12px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>月</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:12px solid rgb(255, 255, 255); left:221px; top:811px; width:11px; height:12px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:221px; top:811px; width:11px; height:12px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>日</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:12px solid rgb(255, 255, 255); left:259px; top:759px; width:103px; height:12px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:259px; top:759px; width:103px; height:12px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>事業所名（所在地）</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:11px solid rgb(255, 255, 255); left:293px; top:781px; width:69px; height:11px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:293px; top:781px; width:69px; height:11px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>（電話番号）</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:13px solid rgb(255, 255, 255); left:409px; top:780px; width:12px; height:13px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:409px; top:780px; width:12px; height:13px; text-align:center; font-size:11px; font-family:'ＭＳ 明朝', serif;</xsl:attribute>－</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:13px solid rgb(255, 255, 255); left:463px; top:780px; width:12px; height:13px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:463px; top:780px; width:12px; height:13px; text-align:center; font-size:11px; font-family:'ＭＳ 明朝', serif;</xsl:attribute>－</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:11px solid rgb(255, 255, 255); left:259px; top:803px; width:53px; height:11px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:259px; top:803px; width:53px; height:11px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>事業主名</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:1px solid rgb(0, 0, 0); left:256px; top:824px; width:473px; line-height:0px; height:0px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:76px solid rgb(255, 255, 255); left:49px; top:827px; width:685px; height:76px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:49px; top:827px; width:685px; height:76px; text-align:left; font-size:14px; font-family:'ＭＳ 明朝', serif; padding:58px 0px 0px 0px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:11px solid rgb(255, 255, 255); left:53px; top:831px; width:309px; height:11px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:53px; top:831px; width:309px; height:11px; text-align:left; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>上記のとおり育児休業給付の受給資格の確認を申請します。</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:12px solid rgb(255, 255, 255); left:53px; top:842px; width:537px; height:12px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:53px; top:842px; width:537px; height:12px; text-align:left; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>雇用保険法施行規則第１０１条の３０の規定により、上記のとおり育児休業給付金の支給を申請します。</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:11px solid rgb(255, 255, 255); left:137px; top:863px; width:11px; height:11px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:137px; top:863px; width:11px; height:11px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>年</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:11px solid rgb(255, 255, 255); left:179px; top:863px; width:11px; height:11px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:179px; top:863px; width:11px; height:11px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>月</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:11px solid rgb(255, 255, 255); left:221px; top:863px; width:11px; height:11px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:221px; top:863px; width:11px; height:11px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>日</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:11px solid rgb(255, 255, 255); left:228px; top:887px; width:92px; height:11px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:228px; top:887px; width:92px; height:11px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>公共職業安定所長</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:11px solid rgb(255, 255, 255); left:330px; top:887px; width:11px; height:11px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:330px; top:887px; width:11px; height:11px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>殿</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:11px solid rgb(255, 255, 255); left:425px; top:856px; width:45px; height:11px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:425px; top:856px; width:45px; height:11px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>フリガナ</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:12px solid rgb(255, 255, 255); left:425px; top:877px; width:57px; height:12px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:425px; top:877px; width:57px; height:12px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>申請者氏名</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:1px solid rgb(0, 0, 0); left:425px; top:898px; width:294px; line-height:0px; height:0px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:97px solid rgb(255, 255, 255); left:49px; top:906px; width:46px; height:97px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:49px; top:906px; width:46px; height:97px; text-align:left; font-size:14px; font-family:'ＭＳ 明朝', serif; padding:79px 0px 0px 0px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:11px solid rgb(255, 255, 255); left:55px; top:918px; width:34px; height:11px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:55px; top:918px; width:34px; height:11px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>払　渡</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:11px solid rgb(255, 255, 255); left:55px; top:933px; width:34px; height:11px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:55px; top:933px; width:34px; height:11px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>希　望</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:12px solid rgb(255, 255, 255); left:55px; top:948px; width:34px; height:12px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:55px; top:948px; width:34px; height:12px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>金　融</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:12px solid rgb(255, 255, 255); left:55px; top:963px; width:34px; height:12px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:55px; top:963px; width:34px; height:12px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>機　関</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:11px solid rgb(255, 255, 255); left:55px; top:979px; width:34px; height:11px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:55px; top:979px; width:34px; height:11px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>指定届</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:97px solid rgb(255, 255, 255); left:94px; top:906px; width:47px; height:97px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:94px; top:906px; width:47px; height:97px; text-align:left; font-size:14px; font-family:'ＭＳ 明朝', serif; padding:79px 0px 0px 0px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:12px solid rgb(255, 255, 255); left:99px; top:910px; width:11px; height:12px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:99px; top:910px; width:11px; height:12px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>43</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:12px solid rgb(255, 255, 255); left:106px; top:925px; width:23px; height:12px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:106px; top:925px; width:23px; height:12px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>払渡</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:11px solid rgb(255, 255, 255); left:106px; top:941px; width:23px; height:11px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:106px; top:941px; width:23px; height:11px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>希望</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:11px solid rgb(255, 255, 255); left:106px; top:956px; width:23px; height:11px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:106px; top:956px; width:23px; height:11px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>金融</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:11px solid rgb(255, 255, 255); left:106px; top:971px; width:23px; height:11px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:106px; top:971px; width:23px; height:11px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>機関</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:16px solid rgb(255, 255, 255); left:140px; top:906px; width:117px; height:16px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:0px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:140px; top:906px; width:117px; height:16px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif; padding:1px 0px 0px 0px;</xsl:attribute>フリガナ</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:27px solid rgb(255, 255, 255); left:140px; top:922px; width:117px; height:27px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); border-top:1px dashed rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:140px; top:922px; width:117px; height:27px; text-align:center; font-size:12px; font-family:'ＭＳ ゴシック', sans-serif; padding:6px 11px 0px 13px;</xsl:attribute>名　　称</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:12px solid rgb(255, 255, 255); left:476px; top:923px; width:24px; height:12px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:476px; top:923px; width:24px; height:12px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>本店</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:11px solid rgb(255, 255, 255); left:476px; top:935px; width:24px; height:11px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:476px; top:935px; width:24px; height:11px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>支店</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:17px solid rgb(255, 255, 255); left:502px; top:906px; width:127px; height:17px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:502px; top:906px; width:127px; height:17px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif; padding:1px 0px 0px 0px;</xsl:attribute>金融機関コード</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:27px solid rgb(255, 255, 255); left:502px; top:922px; width:127px; height:27px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:502px; top:922px; width:127px; height:27px; text-align:left; font-size:14px; font-family:'ＭＳ 明朝', serif; padding:9px 0px 0px 0px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:43px solid rgb(255, 255, 255); left:628px; top:906px; width:5px; height:43px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:628px; top:906px; width:5px; height:43px; text-align:left; font-size:14px; font-family:'ＭＳ 明朝', serif; padding:25px 0px 0px 0px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:17px solid rgb(255, 255, 255); left:632px; top:906px; width:102px; height:17px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:632px; top:906px; width:102px; height:17px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif; padding:1px 0px 0px 0px;</xsl:attribute>店舗コード</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:27px solid rgb(255, 255, 255); left:632px; top:922px; width:102px; height:27px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:632px; top:922px; width:102px; height:27px; text-align:left; font-size:14px; font-family:'ＭＳ 明朝', serif; padding:9px 0px 0px 0px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:28px solid rgb(255, 255, 255); left:140px; top:948px; width:117px; height:28px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:140px; top:948px; width:117px; height:28px; text-align:left; font-size:14px; font-family:'ＭＳ 明朝', serif; padding:10px 0px 0px 0px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:28px solid rgb(255, 255, 255); left:256px; top:948px; width:116px; height:28px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:256px; top:948px; width:116px; height:28px; text-align:center; font-size:12px; font-family:'ＭＳ ゴシック', sans-serif; padding:7px 0px 0px 0px;</xsl:attribute>口<xsl:call-template name="adam-nbsp" />座<xsl:call-template name="adam-nbsp" />番<xsl:call-template name="adam-nbsp" />号</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:28px solid rgb(255, 255, 255); left:371px; top:948px; width:363px; height:28px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:371px; top:948px; width:363px; height:28px; text-align:center; font-size:13px; font-family:'ＭＳ ゴシック', sans-serif; padding:6px 7px 0px 8px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:28px solid rgb(255, 255, 255); left:140px; top:975px; width:117px; height:28px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:140px; top:975px; width:117px; height:28px; text-align:center; font-size:12px; font-family:'ＭＳ ゴシック', sans-serif; padding:7px 0px 0px 0px;</xsl:attribute>ゆうちょ銀行</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:13px solid rgb(255, 255, 255); left:152px; top:950px; width:91px; height:13px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:152px; top:950px; width:91px; height:13px; text-align:center; font-size:12px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>銀　行　等</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:12px solid rgb(255, 255, 255); left:147px; top:962px; width:103px; height:12px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:147px; top:962px; width:103px; height:12px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif; padding:1px 0px 0px 0px;</xsl:attribute>（ゆうちょ銀行以外）</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:28px solid rgb(255, 255, 255); left:256px; top:975px; width:116px; height:28px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:256px; top:975px; width:116px; height:28px; text-align:center; font-size:12px; font-family:'ＭＳ ゴシック', sans-serif; padding:7px 0px 0px 0px;</xsl:attribute>記<xsl:call-template name="adam-nbsp" />号<xsl:call-template name="adam-nbsp" />番<xsl:call-template name="adam-nbsp" />号</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:28px solid rgb(255, 255, 255); left:371px; top:975px; width:363px; height:28px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:371px; top:975px; width:363px; height:28px; text-align:center; font-size:13px; font-family:'ＭＳ ゴシック', sans-serif; padding:6px 7px 0px 8px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:13px solid rgb(255, 255, 255); left:385px; top:982px; width:68px; height:13px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:385px; top:982px; width:68px; height:13px; text-align:center; font-size:12px; font-family:'ＭＳ ゴシック', sans-serif; padding:1px 0px 0px 0px;</xsl:attribute>（<xsl:call-template name="adam-nbsp" />総<xsl:call-template name="adam-nbsp" />合<xsl:call-template name="adam-nbsp" />）</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:19px solid rgb(255, 255, 255); left:552px; top:979px; width:11px; height:19px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:552px; top:979px; width:11px; height:19px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif; padding:3px 0px 0px 0px;</xsl:attribute>－</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:62px solid rgb(255, 255, 255); left:49px; top:1005px; width:18px; height:62px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:49px; top:1005px; width:18px; height:62px; text-align:left; font-size:14px; font-family:'ＭＳ ゴシック', sans-serif; padding:44px 0px 0px 0px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:11px solid rgb(255, 255, 255); left:52px; top:1017px; width:12px; height:11px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:52px; top:1017px; width:12px; height:11px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>備</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:12px solid rgb(255, 255, 255); left:52px; top:1043px; width:12px; height:12px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:52px; top:1043px; width:12px; height:12px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>考</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:18px solid rgb(255, 255, 255); left:66px; top:1005px; width:66px; height:18px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:66px; top:1005px; width:66px; height:18px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif; padding:2px 0px 0px 0px;</xsl:attribute>賃金締切日</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:18px solid rgb(255, 255, 255); left:131px; top:1005px; width:91px; height:18px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:131px; top:1005px; width:91px; height:18px; text-align:right; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif; padding:2px 0px 0px 0px;</xsl:attribute>日</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:19px solid rgb(255, 255, 255); left:66px; top:1022px; width:66px; height:19px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:66px; top:1022px; width:66px; height:19px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif; padding:2px 0px 0px 0px;</xsl:attribute>賃金支払日</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:19px solid rgb(255, 255, 255); left:131px; top:1022px; width:91px; height:19px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:131px; top:1022px; width:91px; height:19px; text-align:right; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif; padding:2px 0px 0px 0px;</xsl:attribute>日</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:36px solid rgb(255, 255, 255); left:221px; top:1005px; width:58px; height:36px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:221px; top:1005px; width:58px; height:36px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif; padding:11px 0px 0px 0px;</xsl:attribute>通勤手当</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:36px solid rgb(255, 255, 255); left:278px; top:1005px; width:157px; height:36px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:278px; top:1005px; width:157px; height:36px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif; padding:11px 0px 0px 0px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:11px solid rgb(255, 255, 255); left:302px; top:1010px; width:15px; height:11px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:302px; top:1010px; width:15px; height:11px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>有</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:11px solid rgb(255, 255, 255); left:302px; top:1025px; width:15px; height:11px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:302px; top:1025px; width:15px; height:11px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>無</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:62px solid rgb(255, 255, 255); left:434px; top:1005px; width:18px; height:62px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:434px; top:1005px; width:18px; height:62px; text-align:left; font-size:14px; font-family:'ＭＳ ゴシック', sans-serif; padding:44px 0px 0px 0px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:11px solid rgb(255, 255, 255); left:437px; top:1013px; width:12px; height:11px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:437px; top:1013px; width:12px; height:11px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>※</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:12px solid rgb(255, 255, 255); left:437px; top:1024px; width:12px; height:12px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:437px; top:1024px; width:12px; height:12px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>処</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:11px solid rgb(255, 255, 255); left:437px; top:1036px; width:12px; height:11px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:437px; top:1036px; width:12px; height:11px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>理</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:12px solid rgb(255, 255, 255); left:437px; top:1047px; width:12px; height:12px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:437px; top:1047px; width:12px; height:12px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>欄</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:22px solid rgb(255, 255, 255); left:451px; top:1005px; width:115px; height:22px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:451px; top:1005px; width:115px; height:22px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif; padding:4px 0px 0px 0px;</xsl:attribute>資<xsl:call-template name="adam-nbsp" />格<xsl:call-template name="adam-nbsp" />確<xsl:call-template name="adam-nbsp" />認<xsl:call-template name="adam-nbsp" />の<xsl:call-template name="adam-nbsp" />可<xsl:call-template name="adam-nbsp" />否</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:22px solid rgb(255, 255, 255); left:565px; top:1005px; width:169px; height:22px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:565px; top:1005px; width:169px; height:22px; text-align:left; font-size:14px; font-family:'ＭＳ ゴシック', sans-serif; padding:4px 0px 0px 0px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:11px solid rgb(255, 255, 255); left:602px; top:1010px; width:11px; height:11px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:602px; top:1010px; width:11px; height:11px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>可</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:11px solid rgb(255, 255, 255); left:686px; top:1010px; width:11px; height:11px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:686px; top:1010px; width:11px; height:11px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>否</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:21px solid rgb(255, 255, 255); left:451px; top:1026px; width:115px; height:21px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:451px; top:1026px; width:115px; height:21px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif; padding:3px 0px 0px 0px;</xsl:attribute>資<xsl:call-template name="adam-nbsp" />格<xsl:call-template name="adam-nbsp" />確<xsl:call-template name="adam-nbsp" />認<xsl:call-template name="adam-nbsp" />年<xsl:call-template name="adam-nbsp" />月<xsl:call-template name="adam-nbsp" />日</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:21px solid rgb(255, 255, 255); left:565px; top:1026px; width:169px; height:21px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:565px; top:1026px; width:169px; height:21px; text-align:left; font-size:10px; font-family:'ＭＳ 明朝', serif; padding:3px 0px 0px 1px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:12px solid rgb(255, 255, 255); left:624px; top:1029px; width:12px; height:12px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:624px; top:1029px; width:12px; height:12px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>年</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:12px solid rgb(255, 255, 255); left:672px; top:1029px; width:12px; height:12px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:672px; top:1029px; width:12px; height:12px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>月</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:12px solid rgb(255, 255, 255); left:719px; top:1030px; width:11px; height:12px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:719px; top:1030px; width:11px; height:12px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>日</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:21px solid rgb(255, 255, 255); left:451px; top:1046px; width:115px; height:21px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:451px; top:1046px; width:115px; height:21px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif; padding:3px 0px 0px 0px;</xsl:attribute>通　知　年　月　日</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:21px solid rgb(255, 255, 255); left:565px; top:1046px; width:169px; height:21px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:565px; top:1046px; width:169px; height:21px; text-align:left; font-size:14px; font-family:'ＭＳ ゴシック', sans-serif; padding:3px 0px 0px 0px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:11px solid rgb(255, 255, 255); left:624px; top:1049px; width:12px; height:11px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:624px; top:1049px; width:12px; height:11px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>年</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:11px solid rgb(255, 255, 255); left:672px; top:1049px; width:12px; height:11px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:672px; top:1049px; width:12px; height:11px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>月</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:11px solid rgb(255, 255, 255); left:719px; top:1049px; width:12px; height:11px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:719px; top:1049px; width:12px; height:11px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>日</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:50px solid rgb(255, 255, 255); left:8px; top:1070px; width:47px; height:50px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:8px; top:1070px; width:47px; height:50px; text-align:left; font-size:14px; font-family:'ＭＳ 明朝', serif; padding:32px 0px 0px 0px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:10px solid rgb(255, 255, 255); left:11px; top:1074px; width:41px; height:10px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:11px; top:1074px; width:41px; height:10px; text-align:center; font-size:8px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>社会保険</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:10px solid rgb(255, 255, 255); left:11px; top:1090px; width:41px; height:10px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:11px; top:1090px; width:41px; height:10px; text-align:center; font-size:8px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>労<xsl:call-template name="adam-nbsp" />務<xsl:call-template name="adam-nbsp" />士</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:10px solid rgb(255, 255, 255); left:11px; top:1106px; width:41px; height:10px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:11px; top:1106px; width:41px; height:10px; text-align:center; font-size:8px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>記<xsl:call-template name="adam-nbsp" />載<xsl:call-template name="adam-nbsp" />欄</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:11px solid rgb(255, 255, 255); left:54px; top:1070px; width:118px; height:11px;</xsl:attribute>
            </xsl:element>
              <xsl:element name="SPAN">
                <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:54px; top:1070px; width:118px; height:11px; text-align:center; font-size:6px; font-family:'ＭＳ ゴシック', sans-serif; padding:2px 0px 0px 2px; display:block; text-align:justify; text-justify:inter-ideograph; text-align-last:justify;</xsl:attribute>作成年月日･提出代行者･事務代理者の表示</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:11px solid rgb(255, 255, 255); left:171px; top:1070px; width:130px; height:11px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:171px; top:1070px; width:130px; height:11px; text-align:center; font-size:8px; font-family:'ＭＳ ゴシック', sans-serif; padding:1px 22px 0px 22px;</xsl:attribute>氏　　　　　　　名</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:40px solid rgb(255, 255, 255); left:291px; top:1080px; width:10px; height:40px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); left:291px; top:1080px; width:10px; height:40px; text-align:center; font-size:8px; font-family:'ＭＳ ゴシック', sans-serif; padding:25px 0px 3px 0px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:11px solid rgb(255, 255, 255); left:300px; top:1070px; width:97px; height:11px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:300px; top:1070px; width:97px; height:11px; text-align:center; font-size:8px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>電　話　番　号</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:40px solid rgb(255, 255, 255); left:300px; top:1080px; width:97px; height:40px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:300px; top:1080px; width:97px; height:40px; text-align:left; font-size:14px; font-family:'ＭＳ 明朝', serif; padding:11px 0px 0px 1px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:13px solid rgb(255, 255, 255); left:342px; top:1085px; width:12px; height:13px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:342px; top:1085px; width:12px; height:13px; text-align:center; font-size:11px; font-family:'ＭＳ 明朝', serif;</xsl:attribute>－</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:13px solid rgb(255, 255, 255); left:342px; top:1103px; width:12px; height:13px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:342px; top:1103px; width:12px; height:13px; text-align:center; font-size:11px; font-family:'ＭＳ 明朝', serif;</xsl:attribute>－</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:8px solid rgb(255, 255, 255); left:397px; top:1070px; width:9px; height:8px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:397px; top:1070px; width:9px; height:8px; text-align:center; font-size:8px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>※</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:50px solid rgb(255, 255, 255); left:407px; top:1070px; width:16px; height:50px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:407px; top:1070px; width:16px; height:50px; text-align:center; font-size:8px; font-family:'ＭＳ ゴシック', sans-serif; padding:19px 0px 5px 1px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:12px solid rgb(255, 255, 255); left:409px; top:1079px; width:12px; height:12px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:409px; top:1079px; width:12px; height:12px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>所</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:12px solid rgb(255, 255, 255); left:409px; top:1098px; width:12px; height:12px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:409px; top:1098px; width:12px; height:12px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>長</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:50px solid rgb(255, 255, 255); left:422px; top:1070px; width:47px; height:50px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:422px; top:1070px; width:47px; height:50px; text-align:left; font-size:14px; font-family:'ＭＳ 明朝', serif; padding:32px 0px 0px 0px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:50px solid rgb(255, 255, 255); left:468px; top:1070px; width:16px; height:50px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:468px; top:1070px; width:16px; height:50px; text-align:center; font-size:8px; font-family:'ＭＳ ゴシック', sans-serif; padding:19px 0px 5px 0px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:12px solid rgb(255, 255, 255); left:470px; top:1079px; width:11px; height:12px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:470px; top:1079px; width:11px; height:12px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>次</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:12px solid rgb(255, 255, 255); left:470px; top:1098px; width:11px; height:12px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:470px; top:1098px; width:11px; height:12px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>長</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:50px solid rgb(255, 255, 255); left:483px; top:1070px; width:47px; height:50px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:483px; top:1070px; width:47px; height:50px; text-align:left; font-size:14px; font-family:'ＭＳ 明朝', serif; padding:32px 0px 0px 0px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:50px solid rgb(255, 255, 255); left:529px; top:1070px; width:16px; height:50px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:529px; top:1070px; width:16px; height:50px; text-align:center; font-size:8px; font-family:'ＭＳ ゴシック', sans-serif; padding:19px 0px 5px 1px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:12px solid rgb(255, 255, 255); left:531px; top:1079px; width:11px; height:12px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:531px; top:1079px; width:11px; height:12px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>課</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:12px solid rgb(255, 255, 255); left:531px; top:1098px; width:11px; height:12px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:531px; top:1098px; width:11px; height:12px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>長</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:50px solid rgb(255, 255, 255); left:544px; top:1070px; width:47px; height:50px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:544px; top:1070px; width:47px; height:50px; text-align:left; font-size:14px; font-family:'ＭＳ 明朝', serif; padding:32px 0px 0px 0px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:50px solid rgb(255, 255, 255); left:590px; top:1070px; width:16px; height:50px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:590px; top:1070px; width:16px; height:50px; text-align:center; font-size:8px; font-family:'ＭＳ ゴシック', sans-serif; padding:19px 0px 5px 1px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:12px solid rgb(255, 255, 255); left:592px; top:1079px; width:11px; height:12px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:592px; top:1079px; width:11px; height:12px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>係</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:12px solid rgb(255, 255, 255); left:592px; top:1098px; width:11px; height:12px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:592px; top:1098px; width:11px; height:12px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>長</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:50px solid rgb(255, 255, 255); left:605px; top:1070px; width:47px; height:50px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:605px; top:1070px; width:47px; height:50px; text-align:left; font-size:14px; font-family:'ＭＳ 明朝', serif; padding:32px 0px 0px 0px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:50px solid rgb(255, 255, 255); left:651px; top:1070px; width:16px; height:50px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:651px; top:1070px; width:16px; height:50px; text-align:center; font-size:8px; font-family:'ＭＳ ゴシック', sans-serif; padding:19px 0px 3px 1px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:11px solid rgb(255, 255, 255); left:653px; top:1089px; width:11px; height:11px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:653px; top:1089px; width:11px; height:11px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>係</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:50px solid rgb(255, 255, 255); left:666px; top:1070px; width:47px; height:50px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:666px; top:1070px; width:47px; height:50px; text-align:left; font-size:14px; font-family:'ＭＳ 明朝', serif; padding:32px 0px 0px 0px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:50px solid rgb(255, 255, 255); left:712px; top:1070px; width:16px; height:50px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:712px; top:1070px; width:16px; height:50px; text-align:center; font-size:8px; font-family:'ＭＳ ゴシック', sans-serif; padding:19px 0px 5px 2px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:11px solid rgb(255, 255, 255); left:713px; top:1074px; width:12px; height:11px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:713px; top:1074px; width:12px; height:11px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>操</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:11px solid rgb(255, 255, 255); left:713px; top:1089px; width:12px; height:11px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:713px; top:1089px; width:12px; height:11px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>作</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:11px solid rgb(255, 255, 255); left:713px; top:1104px; width:12px; height:11px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:713px; top:1104px; width:12px; height:11px; text-align:center; font-size:10px; font-family:'ＭＳ ゴシック', sans-serif;</xsl:attribute>者</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:50px solid rgb(255, 255, 255); left:727px; top:1070px; width:47px; height:50px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:727px; top:1070px; width:47px; height:50px; text-align:left; font-size:14px; font-family:'ＭＳ 明朝', serif; padding:32px 0px 0px 0px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:24px solid rgb(255, 255, 255); left:35px; top:66px; width:97px; height:24px; padding:2px 0px 0px 0px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:35px; top:66px; width:97px; height:24px; text-align:left; font-size:20px; font-family:'ＭＳ ゴシック', sans-serif; padding:2px 0px 0px 1px;</xsl:attribute>
              <xsl:choose>
                <xsl:when test="1">
                  <xsl:call-template name="adam-ins-br">
                    <xsl:with-param name="value" select="translate(帳票種別[1]/text()[1], ' ','&#160;')" />
                  </xsl:call-template>
                </xsl:when>
              </xsl:choose>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:24px solid rgb(255, 255, 0); left:156px; top:66px; width:77px; height:24px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 0); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:156px; top:66px; width:77px; height:24px; text-align:center; font-size:13px; font-family:'ＭＳ 明朝', serif; padding:4px 0px 0px 1px;</xsl:attribute>
              <xsl:choose>
                <xsl:when test="1">
                  <xsl:call-template name="adam-ins-br">
                    <xsl:with-param name="value" select="translate(被保険者番号[1]/被保険者番号4桁[1]/text()[1], ' ','&#160;')" />
                  </xsl:call-template>
                </xsl:when>
              </xsl:choose>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:24px solid rgb(255, 255, 0); left:262px; top:66px; width:116px; height:24px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 0); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:262px; top:66px; width:116px; height:24px; text-align:center; font-size:13px; font-family:'ＭＳ 明朝', serif; padding:4px 0px 0px 1px;</xsl:attribute>
              <xsl:choose>
                <xsl:when test="1">
                  <xsl:call-template name="adam-ins-br">
                    <xsl:with-param name="value" select="translate(被保険者番号[1]/被保険者番号6桁[1]/text()[1], ' ','&#160;')" />
                  </xsl:call-template>
                </xsl:when>
              </xsl:choose>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:24px solid rgb(255, 255, 0); left:407px; top:66px; width:20px; height:24px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 0); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:407px; top:66px; width:20px; height:24px; text-align:center; font-size:13px; font-family:'ＭＳ 明朝', serif; padding:4px 0px 0px 1px;</xsl:attribute>
              <xsl:choose>
                <xsl:when test="1">
                  <xsl:call-template name="adam-ins-br">
                    <xsl:with-param name="value" select="translate(被保険者番号[1]/被保険者番号CD[1]/text()[1], ' ','&#160;')" />
                  </xsl:call-template>
                </xsl:when>
              </xsl:choose>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:24px solid rgb(255, 255, 0); left:508px; top:66px; width:39px; height:24px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 0); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:508px; top:66px; width:39px; height:24px; text-align:center; font-size:12px; font-family:'ＭＳ 明朝', serif; padding:5px 0px 0px 0px;</xsl:attribute>
              <xsl:if test="資格取得年月日[1]/年号[1]/text()[1][. = '']">
                <xsl:call-template name="adam-nbsp" />
              </xsl:if>
              <xsl:if test="資格取得年月日[1]/年号[1]/text()[1][. = '昭和']">昭和</xsl:if>
              <xsl:if test="資格取得年月日[1]/年号[1]/text()[1][. = '平成']">平成</xsl:if>
              <xsl:if test="資格取得年月日[1]/年号[1]/text()[1][. = '令和']">令和</xsl:if>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:24px solid rgb(255, 255, 0); left:552px; top:66px; width:39px; height:24px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 0); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:552px; top:66px; width:39px; height:24px; text-align:right; font-size:13px; font-family:'ＭＳ 明朝', serif; padding:4px 0px 0px 0px;</xsl:attribute>
              <xsl:choose>
                <xsl:when test="1">
                  <xsl:call-template name="adam-ins-br">
                    <xsl:with-param name="value" select="translate(format-number(資格取得年月日[1]/年[1]/text()[1], '0'), ' ','&#160;')" />
                  </xsl:call-template>
                </xsl:when>
              </xsl:choose>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:24px solid rgb(255, 255, 0); left:609px; top:66px; width:39px; height:24px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 0); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:609px; top:66px; width:39px; height:24px; text-align:right; font-size:13px; font-family:'ＭＳ 明朝', serif; padding:4px 0px 0px 0px;</xsl:attribute>
              <xsl:choose>
                <xsl:when test="1">
                  <xsl:call-template name="adam-ins-br">
                    <xsl:with-param name="value" select="translate(format-number(資格取得年月日[1]/月[1]/text()[1], '0'), ' ','&#160;')" />
                  </xsl:call-template>
                </xsl:when>
              </xsl:choose>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:24px solid rgb(255, 255, 0); left:666px; top:66px; width:39px; height:24px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 0); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:666px; top:66px; width:39px; height:24px; text-align:right; font-size:13px; font-family:'ＭＳ 明朝', serif; padding:4px 0px 0px 0px;</xsl:attribute>
              <xsl:choose>
                <xsl:when test="1">
                  <xsl:call-template name="adam-ins-br">
                    <xsl:with-param name="value" select="translate(format-number(資格取得年月日[1]/日[1]/text()[1], '0'), ' ','&#160;')" />
                  </xsl:call-template>
                </xsl:when>
              </xsl:choose>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:24px solid rgb(255, 255, 0); left:11px; top:108px; width:287px; height:24px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 0); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:11px; top:108px; width:287px; height:24px; text-align:left; font-size:13px; font-family:'ＭＳ 明朝', serif; padding:4px 0px 0px 0px;</xsl:attribute>
              <xsl:choose>
                <xsl:when test="1">
                  <xsl:call-template name="adam-ins-br">
                    <xsl:with-param name="value" select="translate(被保険者氏名[1]/text()[1], ' ','&#160;')" />
                  </xsl:call-template>
                </xsl:when>
              </xsl:choose>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:24px solid rgb(255, 255, 0); left:340px; top:108px; width:286px; height:24px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 0); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:340px; top:108px; width:286px; height:24px; text-align:left; font-size:13px; font-family:'ＭＳ 明朝', serif; padding:4px 0px 0px 0px;</xsl:attribute>
              <xsl:choose>
                <xsl:when test="1">
                  <xsl:call-template name="adam-ins-br">
                    <xsl:with-param name="value" select="translate(被保険者氏名フリガナ[1]/text()[1], ' ','&#160;')" />
                  </xsl:call-template>
                </xsl:when>
              </xsl:choose>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:24px solid rgb(255, 255, 0); left:11px; top:150px; width:77px; height:24px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 0); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:11px; top:150px; width:77px; height:24px; text-align:center; font-size:13px; font-family:'ＭＳ 明朝', serif; padding:4px 0px 0px 1px;</xsl:attribute>
              <xsl:choose>
                <xsl:when test="1">
                  <xsl:call-template name="adam-ins-br">
                    <xsl:with-param name="value" select="translate(事業所番号[1]/事業所番号4桁[1]/text()[1], ' ','&#160;')" />
                  </xsl:call-template>
                </xsl:when>
              </xsl:choose>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:24px solid rgb(255, 255, 0); left:118px; top:150px; width:115px; height:24px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 0); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:118px; top:150px; width:115px; height:24px; text-align:center; font-size:13px; font-family:'ＭＳ 明朝', serif; padding:4px 0px 0px 1px;</xsl:attribute>
              <xsl:choose>
                <xsl:when test="1">
                  <xsl:call-template name="adam-ins-br">
                    <xsl:with-param name="value" select="translate(事業所番号[1]/事業所番号6桁[1]/text()[1], ' ','&#160;')" />
                  </xsl:call-template>
                </xsl:when>
              </xsl:choose>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:24px solid rgb(255, 255, 0); left:262px; top:150px; width:20px; height:24px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 0); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:262px; top:150px; width:20px; height:24px; text-align:center; font-size:13px; font-family:'ＭＳ 明朝', serif; padding:4px 0px 0px 1px;</xsl:attribute>
              <xsl:choose>
                <xsl:when test="1">
                  <xsl:call-template name="adam-ins-br">
                    <xsl:with-param name="value" select="translate(事業所番号[1]/事業所番号CD[1]/text()[1], ' ','&#160;')" />
                  </xsl:call-template>
                </xsl:when>
              </xsl:choose>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:24px solid rgb(255, 255, 0); left:319px; top:150px; width:39px; height:24px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 0); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:319px; top:150px; width:39px; height:24px; text-align:center; font-size:12px; font-family:'ＭＳ 明朝', serif; padding:5px 0px 0px 0px;</xsl:attribute>
              <xsl:if test="育児休業開始年月日[1]/年号[1]/text()[1][. = '']">
                <xsl:call-template name="adam-nbsp" />
              </xsl:if>
              <xsl:if test="育児休業開始年月日[1]/年号[1]/text()[1][. = '平成']">平成</xsl:if>
              <xsl:if test="育児休業開始年月日[1]/年号[1]/text()[1][. = '令和']">令和</xsl:if>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:24px solid rgb(255, 255, 0); left:363px; top:150px; width:39px; height:24px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 0); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:363px; top:150px; width:39px; height:24px; text-align:right; font-size:13px; font-family:'ＭＳ 明朝', serif; padding:4px 0px 0px 0px;</xsl:attribute>
              <xsl:choose>
                <xsl:when test="1">
                  <xsl:call-template name="adam-ins-br">
                    <xsl:with-param name="value" select="translate(format-number(育児休業開始年月日[1]/年[1]/text()[1], '0'), ' ','&#160;')" />
                  </xsl:call-template>
                </xsl:when>
              </xsl:choose>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:24px solid rgb(255, 255, 0); left:421px; top:150px; width:39px; height:24px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 0); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:421px; top:150px; width:39px; height:24px; text-align:right; font-size:13px; font-family:'ＭＳ 明朝', serif; padding:4px 0px 0px 0px;</xsl:attribute>
              <xsl:choose>
                <xsl:when test="1">
                  <xsl:call-template name="adam-ins-br">
                    <xsl:with-param name="value" select="translate(format-number(育児休業開始年月日[1]/月[1]/text()[1], '0'), ' ','&#160;')" />
                  </xsl:call-template>
                </xsl:when>
              </xsl:choose>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:24px solid rgb(255, 255, 0); left:478px; top:150px; width:39px; height:24px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 0); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:478px; top:150px; width:39px; height:24px; text-align:right; font-size:13px; font-family:'ＭＳ 明朝', serif; padding:4px 0px 0px 0px;</xsl:attribute>
              <xsl:choose>
                <xsl:when test="1">
                  <xsl:call-template name="adam-ins-br">
                    <xsl:with-param name="value" select="translate(format-number(育児休業開始年月日[1]/日[1]/text()[1], '0'), ' ','&#160;')" />
                  </xsl:call-template>
                </xsl:when>
              </xsl:choose>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:24px solid rgb(255, 255, 0); left:544px; top:150px; width:39px; height:24px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 0); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:544px; top:150px; width:39px; height:24px; text-align:center; font-size:12px; font-family:'ＭＳ 明朝', serif; padding:5px 0px 0px 0px;</xsl:attribute>
              <xsl:if test="出産年月日[1]/年号[1]/text()[1][. = '']">
                <xsl:call-template name="adam-nbsp" />
              </xsl:if>
              <xsl:if test="出産年月日[1]/年号[1]/text()[1][. = '平成']">平成</xsl:if>
              <xsl:if test="出産年月日[1]/年号[1]/text()[1][. = '令和']">令和</xsl:if>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:24px solid rgb(255, 255, 0); left:588px; top:150px; width:39px; height:24px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 0); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:588px; top:150px; width:39px; height:24px; text-align:right; font-size:13px; font-family:'ＭＳ 明朝', serif; padding:4px 0px 0px 0px;</xsl:attribute>
              <xsl:choose>
                <xsl:when test="1">
                  <xsl:call-template name="adam-ins-br">
                    <xsl:with-param name="value" select="translate(format-number(出産年月日[1]/年[1]/text()[1], '0'), ' ','&#160;')" />
                  </xsl:call-template>
                </xsl:when>
              </xsl:choose>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:24px solid rgb(255, 255, 0); left:645px; top:150px; width:39px; height:24px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 0); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:645px; top:150px; width:39px; height:24px; text-align:right; font-size:13px; font-family:'ＭＳ 明朝', serif; padding:4px 0px 0px 0px;</xsl:attribute>
              <xsl:choose>
                <xsl:when test="1">
                  <xsl:call-template name="adam-ins-br">
                    <xsl:with-param name="value" select="translate(format-number(出産年月日[1]/月[1]/text()[1], '0'), ' ','&#160;')" />
                  </xsl:call-template>
                </xsl:when>
              </xsl:choose>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:24px solid rgb(255, 255, 0); left:702px; top:150px; width:39px; height:24px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 0); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:702px; top:150px; width:39px; height:24px; text-align:right; font-size:13px; font-family:'ＭＳ 明朝', serif; padding:4px 0px 0px 0px;</xsl:attribute>
              <xsl:choose>
                <xsl:when test="1">
                  <xsl:call-template name="adam-ins-br">
                    <xsl:with-param name="value" select="translate(format-number(出産年月日[1]/日[1]/text()[1], '0'), ' ','&#160;')" />
                  </xsl:call-template>
                </xsl:when>
              </xsl:choose>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:24px solid rgb(255, 255, 0); left:544px; top:192px; width:39px; height:24px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 0); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:544px; top:192px; width:39px; height:24px; text-align:center; font-size:12px; font-family:'ＭＳ 明朝', serif; padding:5px 0px 0px 0px;</xsl:attribute>
              <xsl:if test="出産予定日[1]/年号[1]/text()[1][. = '']">
                <xsl:call-template name="adam-nbsp" />
              </xsl:if>
              <xsl:if test="出産予定日[1]/年号[1]/text()[1][. = '令和']">令和</xsl:if>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:24px solid rgb(255, 255, 0); left:588px; top:192px; width:39px; height:24px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 0); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:588px; top:192px; width:39px; height:24px; text-align:right; font-size:13px; font-family:'ＭＳ 明朝', serif; padding:4px 0px 0px 0px;</xsl:attribute>
              <xsl:choose>
                <xsl:when test="1">
                  <xsl:call-template name="adam-ins-br">
                    <xsl:with-param name="value" select="translate(format-number(出産予定日[1]/年[1]/text()[1], '0'), ' ','&#160;')" />
                  </xsl:call-template>
                </xsl:when>
              </xsl:choose>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:24px solid rgb(255, 255, 0); left:645px; top:192px; width:39px; height:24px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 0); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:645px; top:192px; width:39px; height:24px; text-align:right; font-size:13px; font-family:'ＭＳ 明朝', serif; padding:4px 0px 0px 0px;</xsl:attribute>
              <xsl:choose>
                <xsl:when test="1">
                  <xsl:call-template name="adam-ins-br">
                    <xsl:with-param name="value" select="translate(format-number(出産予定日[1]/月[1]/text()[1], '0'), ' ','&#160;')" />
                  </xsl:call-template>
                </xsl:when>
              </xsl:choose>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:24px solid rgb(255, 255, 0); left:702px; top:192px; width:39px; height:24px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 0); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:702px; top:192px; width:39px; height:24px; text-align:right; font-size:13px; font-family:'ＭＳ 明朝', serif; padding:4px 0px 0px 0px;</xsl:attribute>
              <xsl:choose>
                <xsl:when test="1">
                  <xsl:call-template name="adam-ins-br">
                    <xsl:with-param name="value" select="translate(format-number(出産予定日[1]/日[1]/text()[1], '0'), ' ','&#160;')" />
                  </xsl:call-template>
                </xsl:when>
              </xsl:choose>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:24px solid rgb(255, 255, 255); left:133px; top:192px; width:20px; height:24px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:133px; top:192px; width:20px; height:24px; text-align:center; font-size:13px; font-family:'ＭＳ 明朝', serif; padding:4px 0px 0px 1px;</xsl:attribute>
              <xsl:choose>
                <xsl:when test="1">
                  <xsl:call-template name="adam-ins-br">
                    <xsl:with-param name="value" select="translate(過去に同一の子について休業取得の有無[1]/text()[1], ' ','&#160;')" />
                  </xsl:call-template>
                </xsl:when>
              </xsl:choose>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:24px solid rgb(255, 255, 0); left:240px; top:192px; width:229px; height:24px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 0); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:240px; top:192px; width:229px; height:24px; text-align:center; font-size:13px; font-family:'ＭＳ 明朝', serif; padding:4px 0px 0px 1px;</xsl:attribute>
              <xsl:choose>
                <xsl:when test="1">
                  <xsl:call-template name="adam-ins-br">
                    <xsl:with-param name="value" select="translate(個人番号[1]/text()[1], ' ','&#160;')" />
                  </xsl:call-template>
                </xsl:when>
              </xsl:choose>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:24px solid rgb(255, 255, 0); left:11px; top:234px; width:39px; height:24px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 0); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:11px; top:234px; width:39px; height:24px; text-align:center; font-size:13px; font-family:'ＭＳ 明朝', serif; padding:4px 0px 0px 1px;</xsl:attribute>
              <xsl:choose>
                <xsl:when test="1">
                  <xsl:call-template name="adam-ins-br">
                    <xsl:with-param name="value" select="translate(被保険者の住所_郵便番号[1]/配達局番号[1]/text()[1], ' ','&#160;')" />
                  </xsl:call-template>
                </xsl:when>
              </xsl:choose>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:24px solid rgb(255, 255, 0); left:86px; top:234px; width:59px; height:24px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 0); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:86px; top:234px; width:59px; height:24px; text-align:center; font-size:13px; font-family:'ＭＳ 明朝', serif; padding:4px 0px 0px 1px;</xsl:attribute>
              <xsl:choose>
                <xsl:when test="1">
                  <xsl:call-template name="adam-ins-br">
                    <xsl:with-param name="value" select="translate(被保険者の住所_郵便番号[1]/町域番号[1]/text()[1], ' ','&#160;')" />
                  </xsl:call-template>
                </xsl:when>
              </xsl:choose>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:24px solid rgb(255, 255, 0); left:339px; top:234px; width:77px; height:24px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 0); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:339px; top:234px; width:77px; height:24px; text-align:center; font-size:13px; font-family:'ＭＳ 明朝', serif; padding:4px 0px 0px 1px;</xsl:attribute>
              <xsl:choose>
                <xsl:when test="1">
                  <xsl:call-template name="adam-ins-br">
                    <xsl:with-param name="value" select="translate(被保険者の電話番号[1]/市外局番[1]/text()[1], ' ','&#160;')" />
                  </xsl:call-template>
                </xsl:when>
              </xsl:choose>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:24px solid rgb(255, 255, 0); left:441px; top:234px; width:78px; height:24px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 0); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:441px; top:234px; width:78px; height:24px; text-align:center; font-size:13px; font-family:'ＭＳ 明朝', serif; padding:4px 0px 0px 1px;</xsl:attribute>
              <xsl:choose>
                <xsl:when test="1">
                  <xsl:call-template name="adam-ins-br">
                    <xsl:with-param name="value" select="translate(被保険者の電話番号[1]/市内局番[1]/text()[1], ' ','&#160;')" />
                  </xsl:call-template>
                </xsl:when>
              </xsl:choose>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:24px solid rgb(255, 255, 0); left:544px; top:234px; width:78px; height:24px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 0); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:544px; top:234px; width:78px; height:24px; text-align:center; font-size:13px; font-family:'ＭＳ 明朝', serif; padding:4px 0px 0px 1px;</xsl:attribute>
              <xsl:choose>
                <xsl:when test="1">
                  <xsl:call-template name="adam-ins-br">
                    <xsl:with-param name="value" select="translate(被保険者の電話番号[1]/加入者番号[1]/text()[1], ' ','&#160;')" />
                  </xsl:call-template>
                </xsl:when>
              </xsl:choose>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:24px solid rgb(255, 255, 0); left:11px; top:276px; width:306px; height:24px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 0); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:11px; top:276px; width:306px; height:24px; text-align:left; font-size:13px; font-family:'ＭＳ 明朝', serif; padding:4px 0px 0px 2px;</xsl:attribute>
              <xsl:choose>
                <xsl:when test="1">
                  <xsl:call-template name="adam-ins-br">
                    <xsl:with-param name="value" select="translate(被保険者の住所_漢字_市区郡及び町村名[1]/text()[1], ' ','&#160;')" />
                  </xsl:call-template>
                </xsl:when>
              </xsl:choose>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:23px solid rgb(255, 255, 0); left:11px; top:318px; width:306px; height:23px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 0); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:11px; top:318px; width:306px; height:23px; text-align:left; font-size:13px; font-family:'ＭＳ 明朝', serif; padding:3px 0px 0px 2px;</xsl:attribute>
              <xsl:choose>
                <xsl:when test="1">
                  <xsl:call-template name="adam-ins-br">
                    <xsl:with-param name="value" select="translate(被保険者の住所_漢字_丁目_番地[1]/text()[1], ' ','&#160;')" />
                  </xsl:call-template>
                </xsl:when>
              </xsl:choose>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:23px solid rgb(255, 255, 0); left:11px; top:360px; width:306px; height:23px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 0); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:11px; top:360px; width:306px; height:23px; text-align:left; font-size:13px; font-family:'ＭＳ 明朝', serif; padding:3px 0px 0px 2px;</xsl:attribute>
              <xsl:choose>
                <xsl:when test="1">
                  <xsl:call-template name="adam-ins-br">
                    <xsl:with-param name="value" select="translate(被保険者の住所_漢字_アパート_マンション名等[1]/text()[1], ' ','&#160;')" />
                  </xsl:call-template>
                </xsl:when>
              </xsl:choose>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:24px solid rgb(255, 255, 0); left:11px; top:401px; width:39px; height:24px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 0); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:11px; top:401px; width:39px; height:24px; text-align:center; font-size:12px; font-family:'ＭＳ 明朝', serif; padding:5px 0px 0px 0px;</xsl:attribute>
              <xsl:if test="支給単位期間1[1]/支給単位期間1_初日[1]/年号[1]/text()[1][. = '']">
                <xsl:call-template name="adam-nbsp" />
              </xsl:if>
              <xsl:if test="支給単位期間1[1]/支給単位期間1_初日[1]/年号[1]/text()[1][. = '平成']">平成</xsl:if>
              <xsl:if test="支給単位期間1[1]/支給単位期間1_初日[1]/年号[1]/text()[1][. = '令和']">令和</xsl:if>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:24px solid rgb(255, 255, 0); left:55px; top:401px; width:39px; height:24px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 0); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:55px; top:401px; width:39px; height:24px; text-align:right; font-size:13px; font-family:'ＭＳ 明朝', serif; padding:4px 0px 0px 0px;</xsl:attribute>
              <xsl:choose>
                <xsl:when test="1">
                  <xsl:call-template name="adam-ins-br">
                    <xsl:with-param name="value" select="translate(format-number(支給単位期間1[1]/支給単位期間1_初日[1]/年[1]/text()[1], '0'), ' ','&#160;')" />
                  </xsl:call-template>
                </xsl:when>
              </xsl:choose>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:24px solid rgb(255, 255, 0); left:108px; top:401px; width:39px; height:24px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 0); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:108px; top:401px; width:39px; height:24px; text-align:right; font-size:13px; font-family:'ＭＳ 明朝', serif; padding:4px 0px 0px 0px;</xsl:attribute>
              <xsl:choose>
                <xsl:when test="1">
                  <xsl:call-template name="adam-ins-br">
                    <xsl:with-param name="value" select="translate(format-number(支給単位期間1[1]/支給単位期間1_初日[1]/月[1]/text()[1], '0'), ' ','&#160;')" />
                  </xsl:call-template>
                </xsl:when>
              </xsl:choose>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:24px solid rgb(255, 255, 0); left:161px; top:401px; width:39px; height:24px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 0); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:161px; top:401px; width:39px; height:24px; text-align:right; font-size:13px; font-family:'ＭＳ 明朝', serif; padding:4px 0px 0px 0px;</xsl:attribute>
              <xsl:choose>
                <xsl:when test="1">
                  <xsl:call-template name="adam-ins-br">
                    <xsl:with-param name="value" select="translate(format-number(支給単位期間1[1]/支給単位期間1_初日[1]/日[1]/text()[1], '0'), ' ','&#160;')" />
                  </xsl:call-template>
                </xsl:when>
              </xsl:choose>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:24px solid rgb(255, 255, 0); left:240px; top:401px; width:39px; height:24px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 0); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:240px; top:401px; width:39px; height:24px; text-align:right; font-size:13px; font-family:'ＭＳ 明朝', serif; padding:4px 0px 0px 0px;</xsl:attribute>
              <xsl:choose>
                <xsl:when test="1">
                  <xsl:call-template name="adam-ins-br">
                    <xsl:with-param name="value" select="translate(format-number(支給単位期間1[1]/支給単位期間1_末日[1]/月[1]/text()[1], '0'), ' ','&#160;')" />
                  </xsl:call-template>
                </xsl:when>
              </xsl:choose>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:24px solid rgb(255, 255, 0); left:293px; top:401px; width:39px; height:24px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 0); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:293px; top:401px; width:39px; height:24px; text-align:right; font-size:13px; font-family:'ＭＳ 明朝', serif; padding:4px 0px 0px 0px;</xsl:attribute>
              <xsl:choose>
                <xsl:when test="1">
                  <xsl:call-template name="adam-ins-br">
                    <xsl:with-param name="value" select="translate(format-number(支給単位期間1[1]/支給単位期間1_末日[1]/日[1]/text()[1], '0'), ' ','&#160;')" />
                  </xsl:call-template>
                </xsl:when>
              </xsl:choose>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:24px solid rgb(255, 255, 0); left:385px; top:401px; width:40px; height:24px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 0); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:385px; top:401px; width:40px; height:24px; text-align:right; font-size:13px; font-family:'ＭＳ 明朝', serif; padding:4px 0px 0px 0px;</xsl:attribute>
              <xsl:choose>
                <xsl:when test="1">
                  <xsl:call-template name="adam-ins-br">
                    <xsl:with-param name="value" select="translate(format-number(就業日数1[1]/text()[1], '0'), ' ','&#160;')" />
                  </xsl:call-template>
                </xsl:when>
              </xsl:choose>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:24px solid rgb(255, 255, 0); left:488px; top:401px; width:39px; height:24px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 0); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:488px; top:401px; width:39px; height:24px; text-align:right; font-size:13px; font-family:'ＭＳ 明朝', serif; padding:4px 0px 0px 0px;</xsl:attribute>
              <xsl:choose>
                <xsl:when test="1">
                  <xsl:call-template name="adam-ins-br">
                    <xsl:with-param name="value" select="translate(format-number(就業時間1[1]/text()[1], '0'), ' ','&#160;')" />
                  </xsl:call-template>
                </xsl:when>
              </xsl:choose>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:24px solid rgb(255, 255, 0); left:595px; top:401px; width:134px; height:24px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 0); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:595px; top:401px; width:134px; height:24px; text-align:right; font-size:13px; font-family:'ＭＳ 明朝', serif; padding:4px 0px 0px 0px;</xsl:attribute>
              <xsl:choose>
                <xsl:when test="1">
                  <xsl:call-template name="adam-ins-br">
                    <xsl:with-param name="value" select="translate(format-number(支払われた賃金額1[1]/text()[1], '0'), ' ','&#160;')" />
                  </xsl:call-template>
                </xsl:when>
              </xsl:choose>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:24px solid rgb(255, 255, 0); left:11px; top:443px; width:39px; height:24px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 0); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:11px; top:443px; width:39px; height:24px; text-align:center; font-size:12px; font-family:'ＭＳ 明朝', serif; padding:5px 0px 0px 0px;</xsl:attribute>
              <xsl:if test="支給単位期間2[1]/支給単位期間2_初日[1]/年号[1]/text()[1][. = '']">
                <xsl:call-template name="adam-nbsp" />
              </xsl:if>
              <xsl:if test="支給単位期間2[1]/支給単位期間2_初日[1]/年号[1]/text()[1][. = '平成']">平成</xsl:if>
              <xsl:if test="支給単位期間2[1]/支給単位期間2_初日[1]/年号[1]/text()[1][. = '令和']">令和</xsl:if>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:24px solid rgb(255, 255, 0); left:55px; top:443px; width:39px; height:24px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 0); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:55px; top:443px; width:39px; height:24px; text-align:right; font-size:13px; font-family:'ＭＳ 明朝', serif; padding:4px 0px 0px 0px;</xsl:attribute>
              <xsl:choose>
                <xsl:when test="1">
                  <xsl:call-template name="adam-ins-br">
                    <xsl:with-param name="value" select="translate(format-number(支給単位期間2[1]/支給単位期間2_初日[1]/年[1]/text()[1], '0'), ' ','&#160;')" />
                  </xsl:call-template>
                </xsl:when>
              </xsl:choose>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:24px solid rgb(255, 255, 0); left:108px; top:443px; width:39px; height:24px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 0); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:108px; top:443px; width:39px; height:24px; text-align:right; font-size:13px; font-family:'ＭＳ 明朝', serif; padding:4px 0px 0px 0px;</xsl:attribute>
              <xsl:choose>
                <xsl:when test="1">
                  <xsl:call-template name="adam-ins-br">
                    <xsl:with-param name="value" select="translate(format-number(支給単位期間2[1]/支給単位期間2_初日[1]/月[1]/text()[1], '0'), ' ','&#160;')" />
                  </xsl:call-template>
                </xsl:when>
              </xsl:choose>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:24px solid rgb(255, 255, 0); left:161px; top:443px; width:39px; height:24px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 0); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:161px; top:443px; width:39px; height:24px; text-align:right; font-size:13px; font-family:'ＭＳ 明朝', serif; padding:4px 0px 0px 0px;</xsl:attribute>
              <xsl:choose>
                <xsl:when test="1">
                  <xsl:call-template name="adam-ins-br">
                    <xsl:with-param name="value" select="translate(format-number(支給単位期間2[1]/支給単位期間2_初日[1]/日[1]/text()[1], '0'), ' ','&#160;')" />
                  </xsl:call-template>
                </xsl:when>
              </xsl:choose>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:24px solid rgb(255, 255, 0); left:240px; top:443px; width:39px; height:24px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 0); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:240px; top:443px; width:39px; height:24px; text-align:right; font-size:13px; font-family:'ＭＳ 明朝', serif; padding:4px 0px 0px 0px;</xsl:attribute>
              <xsl:choose>
                <xsl:when test="1">
                  <xsl:call-template name="adam-ins-br">
                    <xsl:with-param name="value" select="translate(format-number(支給単位期間2[1]/支給単位期間2_末日[1]/月[1]/text()[1], '0'), ' ','&#160;')" />
                  </xsl:call-template>
                </xsl:when>
              </xsl:choose>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:24px solid rgb(255, 255, 0); left:293px; top:443px; width:39px; height:24px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 0); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:293px; top:443px; width:39px; height:24px; text-align:right; font-size:13px; font-family:'ＭＳ 明朝', serif; padding:4px 0px 0px 0px;</xsl:attribute>
              <xsl:choose>
                <xsl:when test="1">
                  <xsl:call-template name="adam-ins-br">
                    <xsl:with-param name="value" select="translate(format-number(支給単位期間2[1]/支給単位期間2_末日[1]/日[1]/text()[1], '0'), ' ','&#160;')" />
                  </xsl:call-template>
                </xsl:when>
              </xsl:choose>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:24px solid rgb(255, 255, 0); left:385px; top:443px; width:40px; height:24px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 0); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:385px; top:443px; width:40px; height:24px; text-align:right; font-size:13px; font-family:'ＭＳ 明朝', serif; padding:4px 0px 0px 0px;</xsl:attribute>
              <xsl:choose>
                <xsl:when test="1">
                  <xsl:call-template name="adam-ins-br">
                    <xsl:with-param name="value" select="translate(format-number(就業日数2[1]/text()[1], '0'), ' ','&#160;')" />
                  </xsl:call-template>
                </xsl:when>
              </xsl:choose>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:24px solid rgb(255, 255, 0); left:488px; top:443px; width:39px; height:24px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 0); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:488px; top:443px; width:39px; height:24px; text-align:right; font-size:13px; font-family:'ＭＳ 明朝', serif; padding:4px 0px 0px 0px;</xsl:attribute>
              <xsl:choose>
                <xsl:when test="1">
                  <xsl:call-template name="adam-ins-br">
                    <xsl:with-param name="value" select="translate(format-number(就業時間2[1]/text()[1], '0'), ' ','&#160;')" />
                  </xsl:call-template>
                </xsl:when>
              </xsl:choose>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:24px solid rgb(255, 255, 0); left:595px; top:443px; width:134px; height:24px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 0); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:595px; top:443px; width:134px; height:24px; text-align:right; font-size:13px; font-family:'ＭＳ 明朝', serif; padding:4px 0px 0px 0px;</xsl:attribute>
              <xsl:choose>
                <xsl:when test="1">
                  <xsl:call-template name="adam-ins-br">
                    <xsl:with-param name="value" select="translate(format-number(支払われた賃金額2[1]/text()[1], '0'), ' ','&#160;')" />
                  </xsl:call-template>
                </xsl:when>
              </xsl:choose>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:24px solid rgb(255, 255, 0); left:11px; top:485px; width:39px; height:24px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 0); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:11px; top:485px; width:39px; height:24px; text-align:center; font-size:12px; font-family:'ＭＳ 明朝', serif; padding:5px 0px 0px 0px;</xsl:attribute>
              <xsl:if test="最終支給単位期間[1]/支給単位期間3_初日[1]/年号[1]/text()[1][. = '']">
                <xsl:call-template name="adam-nbsp" />
              </xsl:if>
              <xsl:if test="最終支給単位期間[1]/支給単位期間3_初日[1]/年号[1]/text()[1][. = '平成']">平成</xsl:if>
              <xsl:if test="最終支給単位期間[1]/支給単位期間3_初日[1]/年号[1]/text()[1][. = '令和']">令和</xsl:if>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:24px solid rgb(255, 255, 0); left:55px; top:485px; width:39px; height:24px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 0); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:55px; top:485px; width:39px; height:24px; text-align:right; font-size:13px; font-family:'ＭＳ 明朝', serif; padding:4px 0px 0px 0px;</xsl:attribute>
              <xsl:choose>
                <xsl:when test="1">
                  <xsl:call-template name="adam-ins-br">
                    <xsl:with-param name="value" select="translate(format-number(最終支給単位期間[1]/支給単位期間3_初日[1]/年[1]/text()[1], '0'), ' ','&#160;')" />
                  </xsl:call-template>
                </xsl:when>
              </xsl:choose>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:24px solid rgb(255, 255, 0); left:108px; top:485px; width:39px; height:24px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 0); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:108px; top:485px; width:39px; height:24px; text-align:right; font-size:13px; font-family:'ＭＳ 明朝', serif; padding:4px 0px 0px 0px;</xsl:attribute>
              <xsl:choose>
                <xsl:when test="1">
                  <xsl:call-template name="adam-ins-br">
                    <xsl:with-param name="value" select="translate(format-number(最終支給単位期間[1]/支給単位期間3_初日[1]/月[1]/text()[1], '0'), ' ','&#160;')" />
                  </xsl:call-template>
                </xsl:when>
              </xsl:choose>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:24px solid rgb(255, 255, 0); left:161px; top:485px; width:39px; height:24px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 0); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:161px; top:485px; width:39px; height:24px; text-align:right; font-size:13px; font-family:'ＭＳ 明朝', serif; padding:4px 0px 0px 0px;</xsl:attribute>
              <xsl:choose>
                <xsl:when test="1">
                  <xsl:call-template name="adam-ins-br">
                    <xsl:with-param name="value" select="translate(format-number(最終支給単位期間[1]/支給単位期間3_初日[1]/日[1]/text()[1], '0'), ' ','&#160;')" />
                  </xsl:call-template>
                </xsl:when>
              </xsl:choose>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:24px solid rgb(255, 255, 0); left:240px; top:485px; width:39px; height:24px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 0); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:240px; top:485px; width:39px; height:24px; text-align:right; font-size:13px; font-family:'ＭＳ 明朝', serif; padding:4px 0px 0px 0px;</xsl:attribute>
              <xsl:choose>
                <xsl:when test="1">
                  <xsl:call-template name="adam-ins-br">
                    <xsl:with-param name="value" select="translate(format-number(最終支給単位期間[1]/支給単位期間3_末日[1]/月[1]/text()[1], '0'), ' ','&#160;')" />
                  </xsl:call-template>
                </xsl:when>
              </xsl:choose>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:24px solid rgb(255, 255, 0); left:293px; top:485px; width:39px; height:24px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 0); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:293px; top:485px; width:39px; height:24px; text-align:right; font-size:13px; font-family:'ＭＳ 明朝', serif; padding:4px 0px 0px 0px;</xsl:attribute>
              <xsl:choose>
                <xsl:when test="1">
                  <xsl:call-template name="adam-ins-br">
                    <xsl:with-param name="value" select="translate(format-number(最終支給単位期間[1]/支給単位期間3_末日[1]/日[1]/text()[1], '0'), ' ','&#160;')" />
                  </xsl:call-template>
                </xsl:when>
              </xsl:choose>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:24px solid rgb(255, 255, 0); left:385px; top:485px; width:40px; height:24px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 0); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:385px; top:485px; width:40px; height:24px; text-align:right; font-size:13px; font-family:'ＭＳ 明朝', serif; padding:4px 0px 0px 0px;</xsl:attribute>
              <xsl:choose>
                <xsl:when test="1">
                  <xsl:call-template name="adam-ins-br">
                    <xsl:with-param name="value" select="translate(format-number(就業日数3[1]/text()[1], '0'), ' ','&#160;')" />
                  </xsl:call-template>
                </xsl:when>
              </xsl:choose>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:24px solid rgb(255, 255, 0); left:488px; top:485px; width:39px; height:24px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 0); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:488px; top:485px; width:39px; height:24px; text-align:right; font-size:13px; font-family:'ＭＳ 明朝', serif; padding:4px 0px 0px 0px;</xsl:attribute>
              <xsl:choose>
                <xsl:when test="1">
                  <xsl:call-template name="adam-ins-br">
                    <xsl:with-param name="value" select="translate(format-number(就業時間3[1]/text()[1], '0'), ' ','&#160;')" />
                  </xsl:call-template>
                </xsl:when>
              </xsl:choose>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:24px solid rgb(255, 255, 0); left:595px; top:485px; width:134px; height:24px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 0); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:595px; top:485px; width:134px; height:24px; text-align:right; font-size:13px; font-family:'ＭＳ 明朝', serif; padding:4px 0px 0px 0px;</xsl:attribute>
              <xsl:choose>
                <xsl:when test="1">
                  <xsl:call-template name="adam-ins-br">
                    <xsl:with-param name="value" select="translate(format-number(支払われた賃金額3[1]/text()[1], '0'), ' ','&#160;')" />
                  </xsl:call-template>
                </xsl:when>
              </xsl:choose>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:24px solid rgb(255, 255, 0); left:11px; top:527px; width:39px; height:24px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 0); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:11px; top:527px; width:39px; height:24px; text-align:center; font-size:12px; font-family:'ＭＳ 明朝', serif; padding:5px 0px 0px 0px;</xsl:attribute>
              <xsl:if test="職場復帰年月日_申請[1]/年号[1]/text()[1][. = '']">
                <xsl:call-template name="adam-nbsp" />
              </xsl:if>
              <xsl:if test="職場復帰年月日_申請[1]/年号[1]/text()[1][. = '平成']">平成</xsl:if>
              <xsl:if test="職場復帰年月日_申請[1]/年号[1]/text()[1][. = '令和']">令和</xsl:if>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:24px solid rgb(255, 255, 0); left:55px; top:527px; width:31px; height:24px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 0); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:55px; top:527px; width:31px; height:24px; text-align:right; font-size:13px; font-family:'ＭＳ 明朝', serif; padding:4px 0px 0px 0px;</xsl:attribute>
              <xsl:choose>
                <xsl:when test="1">
                  <xsl:call-template name="adam-ins-br">
                    <xsl:with-param name="value" select="translate(format-number(職場復帰年月日_申請[1]/年[1]/text()[1], '0'), ' ','&#160;')" />
                  </xsl:call-template>
                </xsl:when>
              </xsl:choose>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:24px solid rgb(255, 255, 0); left:101px; top:527px; width:31px; height:24px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 0); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:101px; top:527px; width:31px; height:24px; text-align:right; font-size:13px; font-family:'ＭＳ 明朝', serif; padding:4px 0px 0px 0px;</xsl:attribute>
              <xsl:choose>
                <xsl:when test="1">
                  <xsl:call-template name="adam-ins-br">
                    <xsl:with-param name="value" select="translate(format-number(職場復帰年月日_申請[1]/月[1]/text()[1], '0'), ' ','&#160;')" />
                  </xsl:call-template>
                </xsl:when>
              </xsl:choose>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:24px solid rgb(255, 255, 0); left:144px; top:527px; width:31px; height:24px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 0); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:144px; top:527px; width:31px; height:24px; text-align:right; font-size:13px; font-family:'ＭＳ 明朝', serif; padding:4px 0px 0px 0px;</xsl:attribute>
              <xsl:choose>
                <xsl:when test="1">
                  <xsl:call-template name="adam-ins-br">
                    <xsl:with-param name="value" select="translate(format-number(職場復帰年月日_申請[1]/日[1]/text()[1], '0'), ' ','&#160;')" />
                  </xsl:call-template>
                </xsl:when>
              </xsl:choose>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:24px solid rgb(255, 255, 0); left:209px; top:527px; width:20px; height:24px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 0); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:209px; top:527px; width:20px; height:24px; text-align:center; font-size:13px; font-family:'ＭＳ 明朝', serif; padding:5px 0px 0px 0px;</xsl:attribute>
              <xsl:if test="支給対象期間延長事由_期間[1]/事由[1]/text()[1][. = '']">
                <xsl:call-template name="adam-nbsp" />
              </xsl:if>
              <xsl:if test="支給対象期間延長事由_期間[1]/事由[1]/text()[1][. = '1']">1</xsl:if>
              <xsl:if test="支給対象期間延長事由_期間[1]/事由[1]/text()[1][. = '2']">2</xsl:if>
              <xsl:if test="支給対象期間延長事由_期間[1]/事由[1]/text()[1][. = '3']">3</xsl:if>
              <xsl:if test="支給対象期間延長事由_期間[1]/事由[1]/text()[1][. = '4']">4</xsl:if>
              <xsl:if test="支給対象期間延長事由_期間[1]/事由[1]/text()[1][. = '5']">5</xsl:if>
              <xsl:if test="支給対象期間延長事由_期間[1]/事由[1]/text()[1][. = '6']">6</xsl:if>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:24px solid rgb(255, 255, 0); left:258px; top:527px; width:39px; height:24px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 0); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:258px; top:527px; width:39px; height:24px; text-align:center; font-size:12px; font-family:'ＭＳ 明朝', serif; padding:5px 0px 0px 0px;</xsl:attribute>
              <xsl:if test="支給対象期間延長事由_期間[1]/延長期間_初日[1]/年号[1]/text()[1][. = '']">
                <xsl:call-template name="adam-nbsp" />
              </xsl:if>
              <xsl:if test="支給対象期間延長事由_期間[1]/延長期間_初日[1]/年号[1]/text()[1][. = '平成']">平成</xsl:if>
              <xsl:if test="支給対象期間延長事由_期間[1]/延長期間_初日[1]/年号[1]/text()[1][. = '令和']">令和</xsl:if>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:24px solid rgb(255, 255, 0); left:302px; top:527px; width:31px; height:24px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 0); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:302px; top:527px; width:31px; height:24px; text-align:right; font-size:13px; font-family:'ＭＳ 明朝', serif; padding:4px 0px 0px 0px;</xsl:attribute>
              <xsl:choose>
                <xsl:when test="1">
                  <xsl:call-template name="adam-ins-br">
                    <xsl:with-param name="value" select="translate(format-number(支給対象期間延長事由_期間[1]/延長期間_初日[1]/年[1]/text()[1], '0'), ' ','&#160;')" />
                  </xsl:call-template>
                </xsl:when>
              </xsl:choose>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:24px solid rgb(255, 255, 0); left:350px; top:527px; width:31px; height:24px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 0); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:350px; top:527px; width:31px; height:24px; text-align:right; font-size:13px; font-family:'ＭＳ 明朝', serif; padding:4px 0px 0px 0px;</xsl:attribute>
              <xsl:choose>
                <xsl:when test="1">
                  <xsl:call-template name="adam-ins-br">
                    <xsl:with-param name="value" select="translate(format-number(支給対象期間延長事由_期間[1]/延長期間_初日[1]/月[1]/text()[1], '0'), ' ','&#160;')" />
                  </xsl:call-template>
                </xsl:when>
              </xsl:choose>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:24px solid rgb(255, 255, 0); left:397px; top:527px; width:31px; height:24px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 0); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:397px; top:527px; width:31px; height:24px; text-align:right; font-size:13px; font-family:'ＭＳ 明朝', serif; padding:4px 0px 0px 0px;</xsl:attribute>
              <xsl:choose>
                <xsl:when test="1">
                  <xsl:call-template name="adam-ins-br">
                    <xsl:with-param name="value" select="translate(format-number(支給対象期間延長事由_期間[1]/延長期間_初日[1]/日[1]/text()[1], '0'), ' ','&#160;')" />
                  </xsl:call-template>
                </xsl:when>
              </xsl:choose>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:24px solid rgb(255, 255, 0); left:470px; top:527px; width:31px; height:24px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 0); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:470px; top:527px; width:31px; height:24px; text-align:right; font-size:13px; font-family:'ＭＳ 明朝', serif; padding:4px 0px 0px 0px;</xsl:attribute>
              <xsl:choose>
                <xsl:when test="1">
                  <xsl:call-template name="adam-ins-br">
                    <xsl:with-param name="value" select="translate(format-number(支給対象期間延長事由_期間[1]/延長期間_末日[1]/月[1]/text()[1], '0'), ' ','&#160;')" />
                  </xsl:call-template>
                </xsl:when>
              </xsl:choose>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:24px solid rgb(255, 255, 0); left:517px; top:527px; width:31px; height:24px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 0); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:517px; top:527px; width:31px; height:24px; text-align:right; font-size:13px; font-family:'ＭＳ 明朝', serif; padding:4px 0px 0px 0px;</xsl:attribute>
              <xsl:choose>
                <xsl:when test="1">
                  <xsl:call-template name="adam-ins-br">
                    <xsl:with-param name="value" select="translate(format-number(支給対象期間延長事由_期間[1]/延長期間_末日[1]/日[1]/text()[1], '0'), ' ','&#160;')" />
                  </xsl:call-template>
                </xsl:when>
              </xsl:choose>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:24px solid rgb(255, 255, 0); left:11px; top:569px; width:39px; height:24px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 0); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:11px; top:569px; width:39px; height:24px; text-align:center; font-size:12px; font-family:'ＭＳ 明朝', serif; padding:5px 0px 0px 0px;</xsl:attribute>
              <xsl:if test="配偶者育休取得[1]/text()[1][. = '']">　</xsl:if>
              <xsl:if test="配偶者育休取得[1]/text()[1][. = '1']">1</xsl:if>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:24px solid rgb(255, 255, 0); left:106px; top:569px; width:77px; height:24px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 0); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:106px; top:569px; width:77px; height:24px; text-align:center; font-size:13px; font-family:'ＭＳ 明朝', serif; padding:4px 0px 0px 1px;</xsl:attribute>
              <xsl:choose>
                <xsl:when test="1">
                  <xsl:call-template name="adam-ins-br">
                    <xsl:with-param name="value" select="translate(配偶者の被保険者番号[1]/配偶者の被保険者番号4桁[1]/text()[1], ' ','&#160;')" />
                  </xsl:call-template>
                </xsl:when>
              </xsl:choose>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:24px solid rgb(255, 255, 0); left:213px; top:569px; width:115px; height:24px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 0); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:213px; top:569px; width:115px; height:24px; text-align:center; font-size:13px; font-family:'ＭＳ 明朝', serif; padding:4px 0px 0px 1px;</xsl:attribute>
              <xsl:choose>
                <xsl:when test="1">
                  <xsl:call-template name="adam-ins-br">
                    <xsl:with-param name="value" select="translate(配偶者の被保険者番号[1]/配偶者の被保険者番号6桁[1]/text()[1], ' ','&#160;')" />
                  </xsl:call-template>
                </xsl:when>
              </xsl:choose>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:24px solid rgb(255, 255, 0); left:358px; top:569px; width:20px; height:24px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 0); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:358px; top:569px; width:20px; height:24px; text-align:center; font-size:13px; font-family:'ＭＳ 明朝', serif; padding:4px 0px 0px 1px;</xsl:attribute>
              <xsl:choose>
                <xsl:when test="1">
                  <xsl:call-template name="adam-ins-br">
                    <xsl:with-param name="value" select="translate(配偶者の被保険者番号[1]/配偶者の被保険者番号CD[1]/text()[1], ' ','&#160;')" />
                  </xsl:call-template>
                </xsl:when>
              </xsl:choose>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:24px solid rgb(255, 255, 255); left:592px; top:577px; width:39px; height:24px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:592px; top:577px; width:39px; height:24px; text-align:center; font-size:12px; font-family:'ＭＳ 明朝', serif; padding:5px 0px 0px 0px;</xsl:attribute>
              <xsl:if test="休業事由の消滅年月日[1]/年号[1]/text()[1][. = '']">
                <xsl:call-template name="adam-nbsp" />
              </xsl:if>
              <xsl:if test="休業事由の消滅年月日[1]/年号[1]/text()[1][. = '平成']">平成</xsl:if>
              <xsl:if test="休業事由の消滅年月日[1]/年号[1]/text()[1][. = '令和']">令和</xsl:if>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:24px solid rgb(255, 255, 255); left:636px; top:577px; width:31px; height:24px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:636px; top:577px; width:31px; height:24px; text-align:right; font-size:13px; font-family:'ＭＳ 明朝', serif; padding:4px 0px 0px 0px;</xsl:attribute>
              <xsl:choose>
                <xsl:when test="1">
                  <xsl:call-template name="adam-ins-br">
                    <xsl:with-param name="value" select="translate(format-number(休業事由の消滅年月日[1]/年[1]/text()[1], '0'), ' ','&#160;')" />
                  </xsl:call-template>
                </xsl:when>
              </xsl:choose>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:24px solid rgb(255, 255, 255); left:683px; top:577px; width:31px; height:24px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:683px; top:577px; width:31px; height:24px; text-align:right; font-size:13px; font-family:'ＭＳ 明朝', serif; padding:4px 0px 0px 0px;</xsl:attribute>
              <xsl:choose>
                <xsl:when test="1">
                  <xsl:call-template name="adam-ins-br">
                    <xsl:with-param name="value" select="translate(format-number(休業事由の消滅年月日[1]/月[1]/text()[1], '0'), ' ','&#160;')" />
                  </xsl:call-template>
                </xsl:when>
              </xsl:choose>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:24px solid rgb(255, 255, 255); left:730px; top:577px; width:31px; height:24px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:730px; top:577px; width:31px; height:24px; text-align:right; font-size:13px; font-family:'ＭＳ 明朝', serif; padding:4px 0px 0px 0px;</xsl:attribute>
              <xsl:choose>
                <xsl:when test="1">
                  <xsl:call-template name="adam-ins-br">
                    <xsl:with-param name="value" select="translate(format-number(休業事由の消滅年月日[1]/日[1]/text()[1], '0'), ' ','&#160;')" />
                  </xsl:call-template>
                </xsl:when>
              </xsl:choose>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:24px solid rgb(255, 255, 255); left:99px; top:619px; width:20px; height:24px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:99px; top:619px; width:20px; height:24px; text-align:center; font-size:13px; font-family:'ＭＳ 明朝', serif; padding:5px 0px 0px 0px;</xsl:attribute>
              <xsl:if test="期間雇用者の継続雇用の見込み[1]/text()[1][. = '']">
                <xsl:call-template name="adam-nbsp" />
              </xsl:if>
              <xsl:if test="期間雇用者の継続雇用の見込み[1]/text()[1][. = '1']">1</xsl:if>
              <xsl:if test="期間雇用者の継続雇用の見込み[1]/text()[1][. = '2']">2</xsl:if>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:24px solid rgb(255, 255, 255); left:166px; top:619px; width:20px; height:24px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:166px; top:619px; width:20px; height:24px; text-align:center; font-size:13px; font-family:'ＭＳ 明朝', serif; padding:5px 0px 0px 0px;</xsl:attribute>
              <xsl:choose>
                <xsl:when test="1">
                  <xsl:call-template name="adam-ins-br">
                    <xsl:with-param name="value" select="translate(format-number(延長等否認[1]/text()[1], '0'), ' ','&#160;')" />
                  </xsl:call-template>
                </xsl:when>
              </xsl:choose>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:24px solid rgb(255, 255, 255); left:200px; top:619px; width:20px; height:24px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:200px; top:619px; width:20px; height:24px; text-align:center; font-size:13px; font-family:'ＭＳ 明朝', serif; padding:5px 0px 0px 0px;</xsl:attribute>
              <xsl:if test="産後休業表示[1]/text()[1][. = '']">
                <xsl:call-template name="adam-nbsp" />
              </xsl:if>
              <xsl:if test="産後休業表示[1]/text()[1][. = '1']">1</xsl:if>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:24px solid rgb(255, 255, 255); left:308px; top:619px; width:20px; height:24px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:308px; top:619px; width:20px; height:24px; text-align:center; font-size:13px; font-family:'ＭＳ 明朝', serif; padding:5px 0px 0px 0px;</xsl:attribute>
              <xsl:if test="賃金月額[1]/賃金月額_区分[1]/text()[1][. = '']">
                <xsl:call-template name="adam-nbsp" />
              </xsl:if>
              <xsl:if test="賃金月額[1]/賃金月額_区分[1]/text()[1][. = '1']">1</xsl:if>
              <xsl:if test="賃金月額[1]/賃金月額_区分[1]/text()[1][. = '2']">2</xsl:if>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:24px solid rgb(255, 255, 255); left:361px; top:619px; width:153px; height:24px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:361px; top:619px; width:153px; height:24px; text-align:right; font-size:13px; font-family:'ＭＳ 明朝', serif; padding:3px 0px 0px 0px;</xsl:attribute>
              <xsl:choose>
                <xsl:when test="1">
                  <xsl:call-template name="adam-ins-br">
                    <xsl:with-param name="value" select="translate(format-number(賃金月額[1]/賃金月額_日額又は総額[1]/text()[1], '0'), ' ','&#160;')" />
                  </xsl:call-template>
                </xsl:when>
              </xsl:choose>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:24px solid rgb(255, 255, 255); left:592px; top:619px; width:39px; height:24px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:592px; top:619px; width:39px; height:24px; text-align:center; font-size:12px; font-family:'ＭＳ 明朝', serif; padding:5px 0px 0px 0px;</xsl:attribute>
              <xsl:if test="当初の育児休業開始年月日[1]/年号[1]/text()[1][. = '']">
                <xsl:call-template name="adam-nbsp" />
              </xsl:if>
              <xsl:if test="当初の育児休業開始年月日[1]/年号[1]/text()[1][. = '平成']">平成</xsl:if>
              <xsl:if test="当初の育児休業開始年月日[1]/年号[1]/text()[1][. = '令和']">令和</xsl:if>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:24px solid rgb(255, 255, 255); left:636px; top:619px; width:31px; height:24px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:636px; top:619px; width:31px; height:24px; text-align:right; font-size:13px; font-family:'ＭＳ 明朝', serif; padding:3px 0px 0px 0px;</xsl:attribute>
              <xsl:choose>
                <xsl:when test="1">
                  <xsl:call-template name="adam-ins-br">
                    <xsl:with-param name="value" select="translate(format-number(当初の育児休業開始年月日[1]/年[1]/text()[1], '0'), ' ','&#160;')" />
                  </xsl:call-template>
                </xsl:when>
              </xsl:choose>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:24px solid rgb(255, 255, 255); left:683px; top:619px; width:31px; height:24px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:683px; top:619px; width:31px; height:24px; text-align:right; font-size:13px; font-family:'ＭＳ 明朝', serif; padding:3px 0px 0px 0px;</xsl:attribute>
              <xsl:choose>
                <xsl:when test="1">
                  <xsl:call-template name="adam-ins-br">
                    <xsl:with-param name="value" select="translate(format-number(当初の育児休業開始年月日[1]/月[1]/text()[1], '0'), ' ','&#160;')" />
                  </xsl:call-template>
                </xsl:when>
              </xsl:choose>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:24px solid rgb(255, 255, 255); left:730px; top:619px; width:32px; height:24px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:730px; top:619px; width:32px; height:24px; text-align:right; font-size:13px; font-family:'ＭＳ 明朝', serif; padding:3px 0px 0px 0px;</xsl:attribute>
              <xsl:choose>
                <xsl:when test="1">
                  <xsl:call-template name="adam-ins-br">
                    <xsl:with-param name="value" select="translate(format-number(当初の育児休業開始年月日[1]/日[1]/text()[1], '0'), ' ','&#160;')" />
                  </xsl:call-template>
                </xsl:when>
              </xsl:choose>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:24px solid rgb(255, 255, 255); left:41px; top:661px; width:39px; height:24px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:41px; top:661px; width:39px; height:24px; text-align:center; font-size:12px; font-family:'ＭＳ 明朝', serif; padding:5px 0px 0px 0px;</xsl:attribute>
              <xsl:if test="受給資格確認年月日[1]/年号[1]/text()[1][. = '']">
                <xsl:call-template name="adam-nbsp" />
              </xsl:if>
              <xsl:if test="受給資格確認年月日[1]/年号[1]/text()[1][. = '平成']">平成</xsl:if>
              <xsl:if test="受給資格確認年月日[1]/年号[1]/text()[1][. = '令和']">令和</xsl:if>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:24px solid rgb(255, 255, 255); left:85px; top:661px; width:31px; height:24px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:85px; top:661px; width:31px; height:24px; text-align:right; font-size:13px; font-family:'ＭＳ 明朝', serif; padding:3px 0px 0px 0px;</xsl:attribute>
              <xsl:choose>
                <xsl:when test="1">
                  <xsl:call-template name="adam-ins-br">
                    <xsl:with-param name="value" select="translate(format-number(受給資格確認年月日[1]/年[1]/text()[1], '0'), ' ','&#160;')" />
                  </xsl:call-template>
                </xsl:when>
              </xsl:choose>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:24px solid rgb(255, 255, 255); left:132px; top:661px; width:31px; height:24px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:132px; top:661px; width:31px; height:24px; text-align:right; font-size:13px; font-family:'ＭＳ 明朝', serif; padding:3px 0px 0px 0px;</xsl:attribute>
              <xsl:choose>
                <xsl:when test="1">
                  <xsl:call-template name="adam-ins-br">
                    <xsl:with-param name="value" select="translate(format-number(受給資格確認年月日[1]/月[1]/text()[1], '0'), ' ','&#160;')" />
                  </xsl:call-template>
                </xsl:when>
              </xsl:choose>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:24px solid rgb(255, 255, 255); left:179px; top:661px; width:31px; height:24px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:179px; top:661px; width:31px; height:24px; text-align:right; font-size:13px; font-family:'ＭＳ 明朝', serif; padding:3px 0px 0px 0px;</xsl:attribute>
              <xsl:choose>
                <xsl:when test="1">
                  <xsl:call-template name="adam-ins-br">
                    <xsl:with-param name="value" select="translate(format-number(受給資格確認年月日[1]/日[1]/text()[1], '0'), ' ','&#160;')" />
                  </xsl:call-template>
                </xsl:when>
              </xsl:choose>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:24px solid rgb(255, 255, 255); left:289px; top:661px; width:20px; height:24px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:289px; top:661px; width:20px; height:24px; text-align:center; font-size:13px; font-family:'ＭＳ 明朝', serif; padding:5px 0px 0px 1px;</xsl:attribute>
              <xsl:if test="受給資格否認[1]/text()[1][. = '']">
                <xsl:call-template name="adam-nbsp" />
              </xsl:if>
              <xsl:if test="受給資格否認[1]/text()[1][. = '1']">1</xsl:if>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:24px solid rgb(255, 255, 255); left:468px; top:661px; width:20px; height:24px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:468px; top:661px; width:20px; height:24px; text-align:center; font-size:13px; font-family:'ＭＳ 明朝', serif; padding:5px 0px 0px 0px;</xsl:attribute>
              <xsl:if test="支給申請月[1]/text()[1][. = '']">
                <xsl:call-template name="adam-nbsp" />
              </xsl:if>
              <xsl:if test="支給申請月[1]/text()[1][. = '1']">1</xsl:if>
              <xsl:if test="支給申請月[1]/text()[1][. = '2']">2</xsl:if>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:24px solid rgb(255, 255, 255); left:592px; top:661px; width:39px; height:24px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:592px; top:661px; width:39px; height:24px; text-align:center; font-size:12px; font-family:'ＭＳ 明朝', serif; padding:5px 0px 0px 0px;</xsl:attribute>
              <xsl:if test="次回支給申請年月日[1]/年号[1]/text()[1][. = '']">
                <xsl:call-template name="adam-nbsp" />
              </xsl:if>
              <xsl:if test="次回支給申請年月日[1]/年号[1]/text()[1][. = '平成']">平成</xsl:if>
              <xsl:if test="次回支給申請年月日[1]/年号[1]/text()[1][. = '令和']">令和</xsl:if>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:24px solid rgb(255, 255, 255); left:636px; top:661px; width:31px; height:24px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:636px; top:661px; width:31px; height:24px; text-align:right; font-size:13px; font-family:'ＭＳ 明朝', serif; padding:3px 0px 0px 0px;</xsl:attribute>
              <xsl:choose>
                <xsl:when test="1">
                  <xsl:call-template name="adam-ins-br">
                    <xsl:with-param name="value" select="translate(format-number(次回支給申請年月日[1]/年[1]/text()[1], '0'), ' ','&#160;')" />
                  </xsl:call-template>
                </xsl:when>
              </xsl:choose>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:24px solid rgb(255, 255, 255); left:683px; top:661px; width:31px; height:24px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:683px; top:661px; width:31px; height:24px; text-align:right; font-size:13px; font-family:'ＭＳ 明朝', serif; padding:3px 0px 0px 0px;</xsl:attribute>
              <xsl:choose>
                <xsl:when test="1">
                  <xsl:call-template name="adam-ins-br">
                    <xsl:with-param name="value" select="translate(format-number(次回支給申請年月日[1]/月[1]/text()[1], '0'), ' ','&#160;')" />
                  </xsl:call-template>
                </xsl:when>
              </xsl:choose>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:24px solid rgb(255, 255, 255); left:730px; top:661px; width:31px; height:24px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:730px; top:661px; width:31px; height:24px; text-align:right; font-size:13px; font-family:'ＭＳ 明朝', serif; padding:3px 0px 0px 0px;</xsl:attribute>
              <xsl:choose>
                <xsl:when test="1">
                  <xsl:call-template name="adam-ins-br">
                    <xsl:with-param name="value" select="translate(format-number(次回支給申請年月日[1]/日[1]/text()[1], '0'), ' ','&#160;')" />
                  </xsl:call-template>
                </xsl:when>
              </xsl:choose>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:24px solid rgb(255, 255, 255); left:41px; top:702px; width:20px; height:24px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:41px; top:702px; width:20px; height:24px; text-align:center; font-size:13px; font-family:'ＭＳ 明朝', serif; padding:5px 0px 0px 0px;</xsl:attribute>
              <xsl:if test="支払区分[1]/text()[1][. = '']">
                <xsl:call-template name="adam-nbsp" />
              </xsl:if>
              <xsl:if test="支払区分[1]/text()[1][. = '1']">1</xsl:if>
              <xsl:if test="支払区分[1]/text()[1][. = '2']">2</xsl:if>
              <xsl:if test="支払区分[1]/text()[1][. = '3']">3</xsl:if>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:24px solid rgb(255, 255, 255); left:140px; top:702px; width:135px; height:24px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:140px; top:702px; width:135px; height:24px; text-align:center; font-size:13px; font-family:'ＭＳ 明朝', serif; padding:4px 0px 0px 1px;</xsl:attribute>
              <xsl:choose>
                <xsl:when test="1">
                  <xsl:call-template name="adam-ins-br">
                    <xsl:with-param name="value" select="translate(金融機関[1]/店舗コード[1]/text()[1], ' ','&#160;')" />
                  </xsl:call-template>
                </xsl:when>
              </xsl:choose>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:24px solid rgb(255, 255, 255); left:300px; top:702px; width:135px; height:24px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:300px; top:702px; width:135px; height:24px; text-align:center; font-size:13px; font-family:'ＭＳ 明朝', serif; padding:4px 0px 0px 1px;</xsl:attribute>
              <xsl:choose>
                <xsl:when test="1">
                  <xsl:call-template name="adam-ins-br">
                    <xsl:with-param name="value" select="translate(金融機関[1]/口座番号[1]/text()[1], ' ','&#160;')" />
                  </xsl:call-template>
                </xsl:when>
              </xsl:choose>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:24px solid rgb(255, 255, 255); left:592px; top:702px; width:20px; height:24px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:592px; top:702px; width:20px; height:24px; text-align:center; font-size:13px; font-family:'ＭＳ 明朝', serif; padding:5px 0px 0px 0px;</xsl:attribute>
              <xsl:if test="未支給区分[1]/text()[1][. = '']">
                <xsl:call-template name="adam-nbsp" />
              </xsl:if>
              <xsl:if test="未支給区分[1]/text()[1][. = '1']">1</xsl:if>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:15px solid rgb(255, 255, 0); left:86px; top:810px; width:23px; height:15px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 0); left:86px; top:810px; width:23px; height:15px; text-align:center; font-size:10px; font-family:'ＭＳ 明朝', serif; padding:1px 0px 0px 0px;</xsl:attribute>
              <xsl:if test="事業主証明欄[1]/事業主証明年月日[1]/年号[1]/text()[1][. = '']">
                <xsl:call-template name="adam-nbsp" />
              </xsl:if>
              <xsl:if test="事業主証明欄[1]/事業主証明年月日[1]/年号[1]/text()[1][. = '平成']">平成</xsl:if>
              <xsl:if test="事業主証明欄[1]/事業主証明年月日[1]/年号[1]/text()[1][. = '令和']">令和</xsl:if>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:15px solid rgb(255, 255, 0); left:114px; top:810px; width:19px; height:15px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 0); left:114px; top:810px; width:19px; height:15px; text-align:right; font-size:11px; font-family:'ＭＳ 明朝', serif; padding:1px 0px 0px 0px;</xsl:attribute>
              <xsl:choose>
                <xsl:when test="1">
                  <xsl:call-template name="adam-ins-br">
                    <xsl:with-param name="value" select="translate(format-number(事業主証明欄[1]/事業主証明年月日[1]/年[1]/text()[1], '0'), ' ','&#160;')" />
                  </xsl:call-template>
                </xsl:when>
              </xsl:choose>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:15px solid rgb(255, 255, 0); left:156px; top:810px; width:19px; height:15px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 0); left:156px; top:810px; width:19px; height:15px; text-align:right; font-size:11px; font-family:'ＭＳ 明朝', serif; padding:1px 0px 0px 0px;</xsl:attribute>
              <xsl:choose>
                <xsl:when test="1">
                  <xsl:call-template name="adam-ins-br">
                    <xsl:with-param name="value" select="translate(format-number(事業主証明欄[1]/事業主証明年月日[1]/月[1]/text()[1], '0'), ' ','&#160;')" />
                  </xsl:call-template>
                </xsl:when>
              </xsl:choose>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:15px solid rgb(255, 255, 0); left:198px; top:810px; width:19px; height:15px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 0); left:198px; top:810px; width:19px; height:15px; text-align:right; font-size:11px; font-family:'ＭＳ 明朝', serif; padding:1px 0px 0px 0px;</xsl:attribute>
              <xsl:choose>
                <xsl:when test="1">
                  <xsl:call-template name="adam-ins-br">
                    <xsl:with-param name="value" select="translate(format-number(事業主証明欄[1]/事業主証明年月日[1]/日[1]/text()[1], '0'), ' ','&#160;')" />
                  </xsl:call-template>
                </xsl:when>
              </xsl:choose>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:26px solid rgb(255, 255, 0); left:369px; top:752px; width:343px; height:26px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; display:table; overflow:hidden; overflow-y:auto; color:rgb(0, 0, 0); background-color:rgb(255, 255, 0); left:369px; top:752px; width:343px; height:26px; text-align:left; font-size:25px; font-family:'ＭＳ 明朝', serif;</xsl:attribute>
              <xsl:element name="SPAN">
                <xsl:attribute name="style">font-size:10px; height:10px; line-height:1em; vertical-align:middle; display:table-cell; word-break:break-all; box-sizing:border-box;</xsl:attribute>
                <xsl:choose>
                  <xsl:when test="1">
                    <xsl:call-template name="adam-ins-br">
                      <xsl:with-param name="value" select="translate(事業主証明欄[1]/事業所名_所在地[1]/text()[1], ' ','&#160;')" />
                    </xsl:call-template>
                  </xsl:when>
                </xsl:choose>
              </xsl:element>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:15px solid rgb(255, 255, 0); left:369px; top:779px; width:38px; height:15px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 0); left:369px; top:779px; width:38px; height:15px; text-align:center; font-size:11px; font-family:'ＭＳ 明朝', serif; padding:1px 0px 0px 0px;</xsl:attribute>
              <xsl:choose>
                <xsl:when test="1">
                  <xsl:call-template name="adam-ins-br">
                    <xsl:with-param name="value" select="translate(事業主証明欄[1]/事業所名_電話番号[1]/市外局番[1]/text()[1], ' ','&#160;')" />
                  </xsl:call-template>
                </xsl:when>
              </xsl:choose>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:15px solid rgb(255, 255, 0); left:423px; top:779px; width:38px; height:15px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 0); left:423px; top:779px; width:38px; height:15px; text-align:center; font-size:11px; font-family:'ＭＳ 明朝', serif; padding:1px 0px 0px 0px;</xsl:attribute>
              <xsl:choose>
                <xsl:when test="1">
                  <xsl:call-template name="adam-ins-br">
                    <xsl:with-param name="value" select="translate(事業主証明欄[1]/事業所名_電話番号[1]/市内局番[1]/text()[1], ' ','&#160;')" />
                  </xsl:call-template>
                </xsl:when>
              </xsl:choose>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:15px solid rgb(255, 255, 0); left:477px; top:779px; width:38px; height:15px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 0); left:477px; top:779px; width:38px; height:15px; text-align:center; font-size:11px; font-family:'ＭＳ 明朝', serif; padding:1px 0px 0px 0px;</xsl:attribute>
              <xsl:choose>
                <xsl:when test="1">
                  <xsl:call-template name="adam-ins-br">
                    <xsl:with-param name="value" select="translate(事業主証明欄[1]/事業所名_電話番号[1]/加入者番号[1]/text()[1], ' ','&#160;')" />
                  </xsl:call-template>
                </xsl:when>
              </xsl:choose>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:27px solid rgb(255, 255, 0); left:369px; top:795px; width:343px; height:27px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; display:table; overflow:hidden; overflow-y:auto; color:rgb(0, 0, 0); background-color:rgb(255, 255, 0); left:369px; top:795px; width:343px; height:27px; text-align:left; font-size:26px; font-family:'ＭＳ 明朝', serif;</xsl:attribute>
              <xsl:element name="SPAN">
                <xsl:attribute name="style">font-size:10px; height:10px; line-height:1em; vertical-align:middle; display:table-cell; word-break:break-all; box-sizing:border-box;</xsl:attribute>
                <xsl:choose>
                  <xsl:when test="1">
                    <xsl:call-template name="adam-ins-br">
                      <xsl:with-param name="value" select="translate(事業主証明欄[1]/事業主氏名[1]/text()[1], ' ','&#160;')" />
                    </xsl:call-template>
                  </xsl:when>
                </xsl:choose>
              </xsl:element>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:15px solid rgb(255, 255, 0); left:86px; top:861px; width:23px; height:15px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 0); left:86px; top:861px; width:23px; height:15px; text-align:center; font-size:10px; font-family:'ＭＳ 明朝', serif; padding:1px 0px 0px 0px;</xsl:attribute>
              <xsl:if test="申請欄[1]/申請年月日[1]/年号[1]/text()[1][. = '']">
                <xsl:call-template name="adam-nbsp" />
              </xsl:if>
              <xsl:if test="申請欄[1]/申請年月日[1]/年号[1]/text()[1][. = '平成']">平成</xsl:if>
              <xsl:if test="申請欄[1]/申請年月日[1]/年号[1]/text()[1][. = '令和']">令和</xsl:if>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:15px solid rgb(255, 255, 0); left:114px; top:861px; width:19px; height:15px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 0); left:114px; top:861px; width:19px; height:15px; text-align:right; font-size:11px; font-family:'ＭＳ 明朝', serif; padding:1px 0px 0px 0px;</xsl:attribute>
              <xsl:choose>
                <xsl:when test="1">
                  <xsl:call-template name="adam-ins-br">
                    <xsl:with-param name="value" select="translate(format-number(申請欄[1]/申請年月日[1]/年[1]/text()[1], '0'), ' ','&#160;')" />
                  </xsl:call-template>
                </xsl:when>
              </xsl:choose>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:15px solid rgb(255, 255, 0); left:156px; top:861px; width:19px; height:15px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 0); left:156px; top:861px; width:19px; height:15px; text-align:right; font-size:11px; font-family:'ＭＳ 明朝', serif; padding:1px 0px 0px 0px;</xsl:attribute>
              <xsl:choose>
                <xsl:when test="1">
                  <xsl:call-template name="adam-ins-br">
                    <xsl:with-param name="value" select="translate(format-number(申請欄[1]/申請年月日[1]/月[1]/text()[1], '0'), ' ','&#160;')" />
                  </xsl:call-template>
                </xsl:when>
              </xsl:choose>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:15px solid rgb(255, 255, 0); left:198px; top:861px; width:19px; height:15px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 0); left:198px; top:861px; width:19px; height:15px; text-align:right; font-size:11px; font-family:'ＭＳ 明朝', serif; padding:1px 0px 0px 0px;</xsl:attribute>
              <xsl:choose>
                <xsl:when test="1">
                  <xsl:call-template name="adam-ins-br">
                    <xsl:with-param name="value" select="translate(format-number(申請欄[1]/申請年月日[1]/日[1]/text()[1], '0'), ' ','&#160;')" />
                  </xsl:call-template>
                </xsl:when>
              </xsl:choose>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:15px solid rgb(255, 255, 0); left:114px; top:884px; width:111px; height:15px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 0); left:114px; top:884px; width:111px; height:15px; text-align:right; font-size:10px; font-family:'ＭＳ 明朝', serif; padding:1px 0px 0px 0px;</xsl:attribute>
              <xsl:choose>
                <xsl:when test="1">
                  <xsl:call-template name="adam-ins-br">
                    <xsl:with-param name="value" select="translate(申請欄[1]/あて先[1]/text()[1], ' ','&#160;')" />
                  </xsl:call-template>
                </xsl:when>
              </xsl:choose>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:15px solid rgb(255, 255, 0); left:489px; top:854px; width:223px; height:15px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 0); left:489px; top:854px; width:223px; height:15px; text-align:left; font-size:10px; font-family:'ＭＳ 明朝', serif; padding:1px 0px 0px 0px;</xsl:attribute>
              <xsl:choose>
                <xsl:when test="1">
                  <xsl:call-template name="adam-ins-br">
                    <xsl:with-param name="value" select="translate(申請欄[1]/申請者氏名_フリガナ[1]/text()[1], ' ','&#160;')" />
                  </xsl:call-template>
                </xsl:when>
              </xsl:choose>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:26px solid rgb(255, 255, 0); left:489px; top:870px; width:223px; height:26px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; display:table; overflow:hidden; overflow-y:auto; color:rgb(0, 0, 0); background-color:rgb(255, 255, 0); left:489px; top:870px; width:223px; height:26px; text-align:left; font-size:25px; font-family:'ＭＳ 明朝', serif;</xsl:attribute>
              <xsl:element name="SPAN">
                <xsl:attribute name="style">font-size:10px; height:10px; line-height:1em; vertical-align:middle; display:table-cell; word-break:break-all; box-sizing:border-box;</xsl:attribute>
                <xsl:choose>
                  <xsl:when test="1">
                    <xsl:call-template name="adam-ins-br">
                      <xsl:with-param name="value" select="translate(申請欄[1]/申請者氏名[1]/text()[1], ' ','&#160;')" />
                    </xsl:call-template>
                  </xsl:when>
                </xsl:choose>
              </xsl:element>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:27px solid rgb(255, 255, 0); left:256px; top:922px; width:205px; height:27px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; display:table; overflow:hidden; overflow-y:auto; color:rgb(0, 0, 0); background-color:rgb(255, 255, 0); border-top:0px solid rgb(0, 0, 0); border-right:0px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:256px; top:922px; width:205px; height:27px; text-align:left; font-size:25px; font-family:'ＭＳ 明朝', serif; padding:0px 0px 0px 1px;</xsl:attribute>
              <xsl:element name="SPAN">
                <xsl:attribute name="style">font-size:10px; height:10px; line-height:1em; vertical-align:middle; display:table-cell; word-break:break-all; box-sizing:border-box;</xsl:attribute>
                <xsl:choose>
                  <xsl:when test="1">
                    <xsl:call-template name="adam-ins-br">
                      <xsl:with-param name="value" select="translate(払渡希望金融機関[1]/金融機関名[1]/text()[1], ' ','&#160;')" />
                    </xsl:call-template>
                  </xsl:when>
                </xsl:choose>
              </xsl:element>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 0); left:463px; top:924px; width:10px; line-height:10px; height:10px; text-align:left; font-size:10px; font-family:'ＭＳ 明朝', serif; white-space:nowrap;</xsl:attribute>
              <xsl:element name="INPUT">
                <xsl:attribute name="type">RADIO</xsl:attribute>
                <xsl:attribute name="style">position:absolute; top:2px; left:2px; box-sizing:border-box; -moz-box-sizing:border-box; width:6px; height:6px; margin:auto;</xsl:attribute>
                <xsl:attribute name="name">J167_本店支店区分</xsl:attribute>
                <xsl:attribute name="id">J167_005F_967B_9358_8E78_9358_8BE6_95AA</xsl:attribute>
                <xsl:attribute name="tabindex">124</xsl:attribute>
                <xsl:attribute name="value">本店</xsl:attribute>
                <xsl:if test="払渡希望金融機関[1]/本店支店区分[1]/text()[1][. = '本店']">
                  <xsl:attribute name="checked">checked</xsl:attribute>
                </xsl:if>
                <xsl:if test="not(払渡希望金融機関[1]/本店支店区分[1]/text()[1][. = '本店'])">
                  <xsl:attribute name="disabled">disabled</xsl:attribute>
                </xsl:if>
              </xsl:element>
              <SPAN style="font-size:14px; height:14px; vertical-align:middle;">
                <xsl:call-template name="adam-nbsp" />
              </SPAN>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 0); left:463px; top:936px; width:10px; line-height:10px; height:10px; text-align:left; font-size:10px; font-family:'ＭＳ 明朝', serif; white-space:nowrap;</xsl:attribute>
              <xsl:element name="INPUT">
                <xsl:attribute name="type">RADIO</xsl:attribute>
                <xsl:attribute name="style">position:absolute; top:2px; left:2px; box-sizing:border-box; -moz-box-sizing:border-box; width:6px; height:6px; margin:auto;</xsl:attribute>
                <xsl:attribute name="name">J167_本店支店区分</xsl:attribute>
                <xsl:attribute name="id">J167_005F_967B_9358_8E78_9358_8BE6_95AA</xsl:attribute>
                <xsl:attribute name="tabindex">125</xsl:attribute>
                <xsl:attribute name="value">支店</xsl:attribute>
                <xsl:if test="払渡希望金融機関[1]/本店支店区分[1]/text()[1][. = '支店']">
                  <xsl:attribute name="checked">checked</xsl:attribute>
                </xsl:if>
                <xsl:if test="not(払渡希望金融機関[1]/本店支店区分[1]/text()[1][. = '支店'])">
                  <xsl:attribute name="disabled">disabled</xsl:attribute>
                </xsl:if>
              </xsl:element>
              <SPAN style="font-size:14px; height:14px; vertical-align:middle;">
                <xsl:call-template name="adam-nbsp" />
              </SPAN>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:15px solid rgb(255, 255, 0); left:544px; top:927px; width:38px; height:15px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 0); left:544px; top:927px; width:38px; height:15px; text-align:center; font-size:11px; font-family:'ＭＳ 明朝', serif; padding:1px 0px 0px 0px;</xsl:attribute>
              <xsl:choose>
                <xsl:when test="1">
                  <xsl:call-template name="adam-ins-br">
                    <xsl:with-param name="value" select="translate(払渡希望金融機関[1]/金融機関コード[1]/text()[1], ' ','&#160;')" />
                  </xsl:call-template>
                </xsl:when>
              </xsl:choose>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:15px solid rgb(255, 255, 0); left:668px; top:928px; width:29px; height:15px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 0); left:668px; top:928px; width:29px; height:15px; text-align:center; font-size:11px; font-family:'ＭＳ 明朝', serif; padding:1px 0px 0px 0px;</xsl:attribute>
              <xsl:choose>
                <xsl:when test="1">
                  <xsl:call-template name="adam-ins-br">
                    <xsl:with-param name="value" select="translate(払渡希望金融機関[1]/店舗コード[1]/text()[1], ' ','&#160;')" />
                  </xsl:call-template>
                </xsl:when>
              </xsl:choose>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:19px solid rgb(255, 255, 0); left:464px; top:952px; width:229px; height:19px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 0); left:464px; top:952px; width:229px; height:19px; text-align:left; font-size:14px; font-family:'ＭＳ 明朝', serif; padding:1px 0px 0px 1px;</xsl:attribute>
              <xsl:choose>
                <xsl:when test="1">
                  <xsl:call-template name="adam-ins-br">
                    <xsl:with-param name="value" select="translate(払渡希望金融機関[1]/預金通帳の口座番号[1]/text()[1], ' ','&#160;')" />
                  </xsl:call-template>
                </xsl:when>
              </xsl:choose>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:19px solid rgb(255, 255, 0); left:464px; top:979px; width:77px; height:19px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 0); left:464px; top:979px; width:77px; height:19px; text-align:left; font-size:14px; font-family:'ＭＳ 明朝', serif; padding:1px 0px 0px 1px;</xsl:attribute>
              <xsl:choose>
                <xsl:when test="1">
                  <xsl:call-template name="adam-ins-br">
                    <xsl:with-param name="value" select="translate(払渡希望金融機関[1]/ゆうちょ銀行[1]/記号番号[1]/text()[1], ' ','&#160;')" />
                  </xsl:call-template>
                </xsl:when>
              </xsl:choose>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:19px solid rgb(255, 255, 0); left:571px; top:979px; width:122px; height:19px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 0); left:571px; top:979px; width:122px; height:19px; text-align:left; font-size:14px; font-family:'ＭＳ 明朝', serif; padding:1px 0px 0px 1px;</xsl:attribute>
              <xsl:choose>
                <xsl:when test="1">
                  <xsl:call-template name="adam-ins-br">
                    <xsl:with-param name="value" select="translate(払渡希望金融機関[1]/ゆうちょ銀行[1]/口座番号[1]/text()[1], ' ','&#160;')" />
                  </xsl:call-template>
                </xsl:when>
              </xsl:choose>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:16px solid rgb(255, 255, 0); left:182px; top:1006px; width:19px; height:16px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 0); left:182px; top:1006px; width:19px; height:16px; text-align:right; font-size:10px; font-family:'ＭＳ 明朝', serif; padding:2px 0px 0px 0px;</xsl:attribute>
              <xsl:choose>
                <xsl:when test="1">
                  <xsl:call-template name="adam-ins-br">
                    <xsl:with-param name="value" select="translate(format-number(備考欄[1]/賃金締切日[1]/text()[1], '0'), ' ','&#160;')" />
                  </xsl:call-template>
                </xsl:when>
              </xsl:choose>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:15px solid rgb(255, 255, 0); left:135px; top:1024px; width:25px; height:15px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 0); left:135px; top:1024px; width:25px; height:15px; text-align:center; font-size:10px; font-family:'ＭＳ 明朝', serif; padding:1px 0px 0px 0px;</xsl:attribute>
              <xsl:if test="備考欄[1]/賃金支払日_当翌月[1]/text()[1][. = '']">
                <xsl:call-template name="adam-nbsp" />
              </xsl:if>
              <xsl:if test="備考欄[1]/賃金支払日_当翌月[1]/text()[1][. = '当月']">当月</xsl:if>
              <xsl:if test="備考欄[1]/賃金支払日_当翌月[1]/text()[1][. = '翌月']">翌月</xsl:if>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:15px solid rgb(255, 255, 0); left:182px; top:1024px; width:19px; height:15px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 0); left:182px; top:1024px; width:19px; height:15px; text-align:right; font-size:10px; font-family:'ＭＳ 明朝', serif; padding:1px 0px 0px 0px;</xsl:attribute>
              <xsl:choose>
                <xsl:when test="1">
                  <xsl:call-template name="adam-ins-br">
                    <xsl:with-param name="value" select="translate(format-number(備考欄[1]/賃金支払日[1]/text()[1], '0'), ' ','&#160;')" />
                  </xsl:call-template>
                </xsl:when>
              </xsl:choose>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 0); left:283px; top:1007px; width:15px; line-height:15px; height:15px; text-align:left; font-size:15px; font-family:'ＭＳ 明朝', serif; white-space:nowrap;</xsl:attribute>
              <xsl:element name="INPUT">
                <xsl:attribute name="type">RADIO</xsl:attribute>
                <xsl:attribute name="style">position:absolute; top:2px; left:3px; box-sizing:border-box; -moz-box-sizing:border-box; width:10px; height:10px; margin:auto;</xsl:attribute>
                <xsl:attribute name="name">J178_通勤手当の有無</xsl:attribute>
                <xsl:attribute name="id">J178_005F_92CA_8BCE_8EE8_9396_82CC_974C_96B3</xsl:attribute>
                <xsl:attribute name="tabindex">134</xsl:attribute>
                <xsl:attribute name="value">有</xsl:attribute>
                <xsl:if test="備考欄[1]/通勤手当の有無[1]/text()[1][. = '有']">
                  <xsl:attribute name="checked">checked</xsl:attribute>
                </xsl:if>
                <xsl:if test="not(備考欄[1]/通勤手当の有無[1]/text()[1][. = '有'])">
                  <xsl:attribute name="disabled">disabled</xsl:attribute>
                </xsl:if>
              </xsl:element>
              <SPAN style="font-size:14px; height:14px; vertical-align:middle;">
                <xsl:call-template name="adam-nbsp" />
              </SPAN>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 0); left:283px; top:1022px; width:15px; line-height:15px; height:15px; text-align:left; font-size:15px; font-family:'ＭＳ 明朝', serif; white-space:nowrap;</xsl:attribute>
              <xsl:element name="INPUT">
                <xsl:attribute name="type">RADIO</xsl:attribute>
                <xsl:attribute name="style">position:absolute; top:2px; left:3px; box-sizing:border-box; -moz-box-sizing:border-box; width:10px; height:10px; margin:auto;</xsl:attribute>
                <xsl:attribute name="name">J178_通勤手当の有無</xsl:attribute>
                <xsl:attribute name="id">J178_005F_92CA_8BCE_8EE8_9396_82CC_974C_96B3</xsl:attribute>
                <xsl:attribute name="tabindex">135</xsl:attribute>
                <xsl:attribute name="value">無</xsl:attribute>
                <xsl:if test="備考欄[1]/通勤手当の有無[1]/text()[1][. = '無']">
                  <xsl:attribute name="checked">checked</xsl:attribute>
                </xsl:if>
                <xsl:if test="not(備考欄[1]/通勤手当の有無[1]/text()[1][. = '無'])">
                  <xsl:attribute name="disabled">disabled</xsl:attribute>
                </xsl:if>
              </xsl:element>
              <SPAN style="font-size:14px; height:14px; vertical-align:middle;">
                <xsl:call-template name="adam-nbsp" />
              </SPAN>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:15px solid rgb(255, 255, 0); left:318px; top:1007px; width:38px; height:15px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 0); left:318px; top:1007px; width:38px; height:15px; text-align:center; font-size:10px; font-family:'ＭＳ 明朝', serif; padding:1px 0px 0px 0px;</xsl:attribute>
              <xsl:if test="備考欄[1]/通勤手当の期間[1]/text()[1][. = '']">
                <xsl:call-template name="adam-nbsp" />
              </xsl:if>
              <xsl:if test="備考欄[1]/通勤手当の期間[1]/text()[1][. = '毎月']">毎月</xsl:if>
              <xsl:if test="備考欄[1]/通勤手当の期間[1]/text()[1][. = '３か月']">３か月</xsl:if>
              <xsl:if test="備考欄[1]/通勤手当の期間[1]/text()[1][. = '６か月']">６か月</xsl:if>
              <xsl:if test="備考欄[1]/通勤手当の期間[1]/text()[1][. = 'その他']">その他</xsl:if>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:15px solid rgb(255, 255, 0); left:378px; top:1007px; width:46px; height:15px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 0); left:378px; top:1007px; width:46px; height:15px; text-align:left; font-size:10px; font-family:'ＭＳ 明朝', serif; padding:1px 0px 0px 0px;</xsl:attribute>
              <xsl:choose>
                <xsl:when test="1">
                  <xsl:call-template name="adam-ins-br">
                    <xsl:with-param name="value" select="translate(備考欄[1]/通勤手当の期間_その他[1]/text()[1], ' ','&#160;')" />
                  </xsl:call-template>
                </xsl:when>
              </xsl:choose>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); left:580px; top:1009px; width:13px; line-height:13px; height:13px; text-align:left; font-size:13px; font-family:'ＭＳ 明朝', serif; white-space:nowrap;</xsl:attribute>
              <xsl:element name="INPUT">
                <xsl:attribute name="type">RADIO</xsl:attribute>
                <xsl:attribute name="style">position:absolute; top:1px; left:0px; box-sizing:border-box; -moz-box-sizing:border-box; width:10px; height:10px; margin:auto;</xsl:attribute>
                <xsl:attribute name="name">J183_資格確認可否</xsl:attribute>
                <xsl:attribute name="id">J183_005F_8E91_8A69_8A6D_9446_89C2_94DB</xsl:attribute>
                <xsl:attribute name="tabindex">139</xsl:attribute>
                <xsl:attribute name="value">可</xsl:attribute>
                <xsl:if test="処理欄[1]/資格確認可否[1]/text()[1][. = '可']">
                  <xsl:attribute name="checked">checked</xsl:attribute>
                </xsl:if>
                <xsl:if test="not(処理欄[1]/資格確認可否[1]/text()[1][. = '可'])">
                  <xsl:attribute name="disabled">disabled</xsl:attribute>
                </xsl:if>
              </xsl:element>
              <SPAN style="font-size:14px; height:14px; vertical-align:middle;">
                <xsl:call-template name="adam-nbsp" />
              </SPAN>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); left:660px; top:1009px; width:13px; line-height:13px; height:13px; text-align:left; font-size:13px; font-family:'ＭＳ 明朝', serif; white-space:nowrap;</xsl:attribute>
              <xsl:element name="INPUT">
                <xsl:attribute name="type">RADIO</xsl:attribute>
                <xsl:attribute name="style">position:absolute; top:1px; left:0px; box-sizing:border-box; -moz-box-sizing:border-box; width:10px; height:10px; margin:auto;</xsl:attribute>
                <xsl:attribute name="name">J183_資格確認可否</xsl:attribute>
                <xsl:attribute name="id">J183_005F_8E91_8A69_8A6D_9446_89C2_94DB</xsl:attribute>
                <xsl:attribute name="tabindex">140</xsl:attribute>
                <xsl:attribute name="value">否</xsl:attribute>
                <xsl:if test="処理欄[1]/資格確認可否[1]/text()[1][. = '否']">
                  <xsl:attribute name="checked">checked</xsl:attribute>
                </xsl:if>
                <xsl:if test="not(処理欄[1]/資格確認可否[1]/text()[1][. = '否'])">
                  <xsl:attribute name="disabled">disabled</xsl:attribute>
                </xsl:if>
              </xsl:element>
              <SPAN style="font-size:14px; height:14px; vertical-align:middle;">
                <xsl:call-template name="adam-nbsp" />
              </SPAN>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:16px solid rgb(255, 255, 255); left:568px; top:1029px; width:23px; height:16px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:568px; top:1029px; width:23px; height:16px; text-align:center; font-size:10px; font-family:'ＭＳ 明朝', serif;</xsl:attribute>
              <xsl:if test="処理欄[1]/資格確認年月日[1]/年号[1]/text()[1][. = '']">
                <xsl:call-template name="adam-nbsp" />
              </xsl:if>
              <xsl:if test="処理欄[1]/資格確認年月日[1]/年号[1]/text()[1][. = '平成']">平成</xsl:if>
              <xsl:if test="処理欄[1]/資格確認年月日[1]/年号[1]/text()[1][. = '令和']">令和</xsl:if>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:15px solid rgb(255, 255, 255); left:600px; top:1029px; width:17px; height:15px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:600px; top:1029px; width:17px; height:15px; text-align:right; font-size:10px; font-family:'ＭＳ 明朝', serif;</xsl:attribute>
              <xsl:choose>
                <xsl:when test="1">
                  <xsl:call-template name="adam-ins-br">
                    <xsl:with-param name="value" select="translate(format-number(処理欄[1]/資格確認年月日[1]/年[1]/text()[1], '0'), ' ','&#160;')" />
                  </xsl:call-template>
                </xsl:when>
              </xsl:choose>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:15px solid rgb(255, 255, 255); left:645px; top:1029px; width:17px; height:15px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:645px; top:1029px; width:17px; height:15px; text-align:right; font-size:10px; font-family:'ＭＳ 明朝', serif;</xsl:attribute>
              <xsl:choose>
                <xsl:when test="1">
                  <xsl:call-template name="adam-ins-br">
                    <xsl:with-param name="value" select="translate(format-number(処理欄[1]/資格確認年月日[1]/月[1]/text()[1], '0'), ' ','&#160;')" />
                  </xsl:call-template>
                </xsl:when>
              </xsl:choose>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:15px solid rgb(255, 255, 255); left:694px; top:1029px; width:17px; height:15px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:694px; top:1029px; width:17px; height:15px; text-align:right; font-size:10px; font-family:'ＭＳ 明朝', serif;</xsl:attribute>
              <xsl:choose>
                <xsl:when test="1">
                  <xsl:call-template name="adam-ins-br">
                    <xsl:with-param name="value" select="translate(format-number(処理欄[1]/資格確認年月日[1]/日[1]/text()[1], '0'), ' ','&#160;')" />
                  </xsl:call-template>
                </xsl:when>
              </xsl:choose>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:16px solid rgb(255, 255, 255); left:568px; top:1049px; width:23px; height:16px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:568px; top:1049px; width:23px; height:16px; text-align:center; font-size:10px; font-family:'ＭＳ 明朝', serif;</xsl:attribute>
              <xsl:if test="処理欄[1]/通知年月日[1]/年号[1]/text()[1][. = '']">
                <xsl:call-template name="adam-nbsp" />
              </xsl:if>
              <xsl:if test="処理欄[1]/通知年月日[1]/年号[1]/text()[1][. = '平成']">平成</xsl:if>
              <xsl:if test="処理欄[1]/通知年月日[1]/年号[1]/text()[1][. = '令和']">令和</xsl:if>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:15px solid rgb(255, 255, 255); left:600px; top:1049px; width:17px; height:15px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:600px; top:1049px; width:17px; height:15px; text-align:right; font-size:10px; font-family:'ＭＳ 明朝', serif;</xsl:attribute>
              <xsl:choose>
                <xsl:when test="1">
                  <xsl:call-template name="adam-ins-br">
                    <xsl:with-param name="value" select="translate(format-number(処理欄[1]/通知年月日[1]/年[1]/text()[1], '0'), ' ','&#160;')" />
                  </xsl:call-template>
                </xsl:when>
              </xsl:choose>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:15px solid rgb(255, 255, 255); left:645px; top:1049px; width:17px; height:15px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:645px; top:1049px; width:17px; height:15px; text-align:right; font-size:10px; font-family:'ＭＳ 明朝', serif;</xsl:attribute>
              <xsl:choose>
                <xsl:when test="1">
                  <xsl:call-template name="adam-ins-br">
                    <xsl:with-param name="value" select="translate(format-number(処理欄[1]/通知年月日[1]/月[1]/text()[1], '0'), ' ','&#160;')" />
                  </xsl:call-template>
                </xsl:when>
              </xsl:choose>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:15px solid rgb(255, 255, 255); left:694px; top:1049px; width:17px; height:15px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:694px; top:1049px; width:17px; height:15px; text-align:right; font-size:10px; font-family:'ＭＳ 明朝', serif;</xsl:attribute>
              <xsl:choose>
                <xsl:when test="1">
                  <xsl:call-template name="adam-ins-br">
                    <xsl:with-param name="value" select="translate(format-number(処理欄[1]/通知年月日[1]/日[1]/text()[1], '0'), ' ','&#160;')" />
                  </xsl:call-template>
                </xsl:when>
              </xsl:choose>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:40px solid rgb(255, 255, 0); left:54px; top:1080px; width:118px; height:40px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; display:table; overflow:hidden; overflow-y:auto; color:rgb(0, 0, 0); background-color:rgb(255, 255, 0); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:54px; top:1080px; width:118px; height:40px; text-align:left; font-size:37px; font-family:'ＭＳ 明朝', serif; padding:0px 0px 0px 1px;</xsl:attribute>
              <xsl:element name="SPAN">
                <xsl:attribute name="style">font-size:10px; height:10px; line-height:1em; vertical-align:middle; display:table-cell; word-break:break-all; box-sizing:border-box;</xsl:attribute>
                <xsl:choose>
                  <xsl:when test="1">
                    <xsl:call-template name="adam-ins-br">
                      <xsl:with-param name="value" select="translate(社会保険労務士記載欄[1]/作成年月日_提出代行者_事務代理者[1]/text()[1], ' ','&#160;')" />
                    </xsl:call-template>
                  </xsl:when>
                </xsl:choose>
              </xsl:element>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:40px solid rgb(255, 255, 0); left:171px; top:1080px; width:120px; height:40px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; display:table; overflow:hidden; overflow-y:auto; color:rgb(0, 0, 0); background-color:rgb(255, 255, 0); border-top:1px solid rgb(0, 0, 0); border-right:0px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:171px; top:1080px; width:120px; height:40px; text-align:left; font-size:37px; font-family:'ＭＳ 明朝', serif; padding:0px 0px 0px 1px;</xsl:attribute>
              <xsl:element name="SPAN">
                <xsl:attribute name="style">font-size:10px; height:10px; line-height:1em; vertical-align:middle; display:table-cell; word-break:break-all; box-sizing:border-box;</xsl:attribute>
                <xsl:choose>
                  <xsl:when test="1">
                    <xsl:call-template name="adam-ins-br">
                      <xsl:with-param name="value" select="translate(社会保険労務士記載欄[1]/社会保険労務士_氏名[1]/text()[1], ' ','&#160;')" />
                    </xsl:call-template>
                  </xsl:when>
                </xsl:choose>
              </xsl:element>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:13px solid rgb(255, 255, 0); left:302px; top:1085px; width:38px; height:13px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 0); left:302px; top:1085px; width:38px; height:13px; text-align:center; font-size:11px; font-family:'ＭＳ 明朝', serif;</xsl:attribute>
              <xsl:choose>
                <xsl:when test="1">
                  <xsl:call-template name="adam-ins-br">
                    <xsl:with-param name="value" select="translate(社会保険労務士記載欄[1]/電話番号[1]/市外局番[1]/text()[1], ' ','&#160;')" />
                  </xsl:call-template>
                </xsl:when>
              </xsl:choose>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:13px solid rgb(255, 255, 0); left:302px; top:1103px; width:38px; height:13px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 0); left:302px; top:1103px; width:38px; height:13px; text-align:center; font-size:11px; font-family:'ＭＳ 明朝', serif;</xsl:attribute>
              <xsl:choose>
                <xsl:when test="1">
                  <xsl:call-template name="adam-ins-br">
                    <xsl:with-param name="value" select="translate(社会保険労務士記載欄[1]/電話番号[1]/市内局番[1]/text()[1], ' ','&#160;')" />
                  </xsl:call-template>
                </xsl:when>
              </xsl:choose>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:13px solid rgb(255, 255, 0); left:356px; top:1103px; width:38px; height:13px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 0); left:356px; top:1103px; width:38px; height:13px; text-align:center; font-size:11px; font-family:'ＭＳ 明朝', serif;</xsl:attribute>
              <xsl:choose>
                <xsl:when test="1">
                  <xsl:call-template name="adam-ins-br">
                    <xsl:with-param name="value" select="translate(社会保険労務士記載欄[1]/電話番号[1]/加入者番号[1]/text()[1], ' ','&#160;')" />
                  </xsl:call-template>
                </xsl:when>
              </xsl:choose>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; display:none; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:746px; top:1047px; width:24px; height:16px; text-align:left; font-size:14px; font-family:'ＭＳ 明朝', serif;</xsl:attribute>
              <xsl:choose>
                <xsl:when test="1">
                  <xsl:call-template name="adam-ins-br">
                    <xsl:with-param name="value" select="translate(Xmit[1]/text()[1], ' ','&#160;')" />
                  </xsl:call-template>
                </xsl:when>
              </xsl:choose>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; display:none; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:754px; top:99px; width:31px; height:23px; text-align:left; font-size:14px; font-family:'ＭＳ 明朝', serif; padding:5px 0px 0px 0px;</xsl:attribute>A-250075-007_1</xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:17px solid rgb(255, 255, 0); left:256px; top:906px; width:247px; height:17px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 0); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px dashed rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:256px; top:906px; width:247px; height:17px; text-align:left; font-size:10px; font-family:'ＭＳ 明朝', serif; padding:1px 0px 0px 0px;</xsl:attribute>
              <xsl:choose>
                <xsl:when test="1">
                  <xsl:call-template name="adam-ins-br">
                    <xsl:with-param name="value" select="translate(払渡希望金融機関[1]/金融機関フリガナ[1]/text()[1], ' ','&#160;')" />
                  </xsl:call-template>
                </xsl:when>
              </xsl:choose>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:24px solid rgb(255, 255, 0); left:396px; top:569px; width:20px; height:24px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 0); border-top:1px solid rgb(0, 0, 0); border-right:1px solid rgb(0, 0, 0); border-bottom:1px solid rgb(0, 0, 0); border-left:1px solid rgb(0, 0, 0); left:396px; top:569px; width:20px; height:24px; text-align:center; font-size:13px; font-family:'ＭＳ 明朝', serif; padding:5px 0px 0px 0px;</xsl:attribute>
              <xsl:if test="育児休業再取得理由[1]/text()[1][. = '']">
                <xsl:call-template name="adam-nbsp" />
              </xsl:if>
              <xsl:if test="育児休業再取得理由[1]/text()[1][. = '1']">1</xsl:if>
              <xsl:if test="育児休業再取得理由[1]/text()[1][. = '2']">2</xsl:if>
              <xsl:if test="育児休業再取得理由[1]/text()[1][. = '3']">3</xsl:if>
              <xsl:if test="育児休業再取得理由[1]/text()[1][. = '5']">5</xsl:if>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; border-top:13px solid rgb(255, 255, 255); left:385px; top:956px; width:68px; height:13px;</xsl:attribute>
            </xsl:element>
            <xsl:element name="SPAN">
              <xsl:attribute name="style">position:absolute; box-sizing:border-box; -moz-box-sizing:border-box; overflow:hidden; color:rgb(0, 0, 0); background-color:rgb(255, 255, 255); left:385px; top:956px; width:68px; height:13px; text-align:center; font-size:12px; font-family:'ＭＳ ゴシック', sans-serif; padding:1px 0px 0px 0px;</xsl:attribute>（<xsl:call-template name="adam-nbsp" />普<xsl:call-template name="adam-nbsp" />通<xsl:call-template name="adam-nbsp" />）</xsl:element>
          </DIV>
        </FORM>
      </BODY>
    </HTML>
  </xsl:template>
  <xsl:template name="adam-nbsp">
    <xsl:text disable-output-escaping="yes">&amp;nbsp;</xsl:text>
  </xsl:template>
  <xsl:template name="adam-br">
    <xsl:text disable-output-escaping="yes">&lt;BR /&gt;</xsl:text>
  </xsl:template>
  <xsl:template name="adam-ins-br">
    <xsl:param name="value" />
    <xsl:choose>
      <xsl:when test="contains($value,'&#xA;')">
        <xsl:value-of select="normalize-space(substring-before($value,'&#xA;'))" />
        <BR />
        <xsl:call-template name="adam-ins-br">
          <xsl:with-param name="value" select="substring-after($value,'&#xA;')" />
        </xsl:call-template>
      </xsl:when>
      <xsl:otherwise>
        <xsl:value-of select="$value" />
      </xsl:otherwise>
    </xsl:choose>
  </xsl:template>
  <xsl:template match="/DataRoot/様式ID" />
  <xsl:template match="/DataRoot/様式バージョン" />
  <xsl:template match="/DataRoot/STYLESHEET" />
  <xsl:template match="/DataRoot/様式コピー情報" />
  <xsl:template match="/DataRoot/Doctype" />
</xsl:stylesheet>