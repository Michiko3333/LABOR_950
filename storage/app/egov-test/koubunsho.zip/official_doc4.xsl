<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" version="1.0">
<xsl:output method="html" encoding="UTF-8" indent="yes" />

<xsl:template match="DOC">
	<xsl:apply-templates select="BODY"/>
</xsl:template>

<xsl:template match="BODY">
<HTML>
	<HEAD>
		<TITLE><xsl:value-of select="TITLE"/></TITLE>
	</HEAD>
	<BODY>
		<PRE>
			<TABLE border="0" cellspacing="0" cellpadding="0" BGCOLOR="#FFFBF0" width="580" align="center">
				<TR><TD>
					<TABLE border="0" cellspacing="0" cellpadding="0" ALIGN="RIGHT">
						<TR>
							<TD><xsl:value-of select="DOCNO"/></TD>
							<TD><xsl:text>　</xsl:text></TD>
							<TD><xsl:text>　</xsl:text></TD>
						</TR>

						<TR><TD>
								<xsl:if test="DATE!=''">
									<xsl:value-of select="DATE"/>
								</xsl:if>
							</TD>
							<TD><xsl:text>　</xsl:text></TD>
							<TD><xsl:text>　</xsl:text></TD>
						</TR>
					</TABLE>
				</TD></TR>

				<TR><TD><xsl:text>　</xsl:text></TD></TR>
				<TR><TD><xsl:text>　</xsl:text></TD></TR>

				<TR><TD>
					<TABLE border="0" cellspacing="0" cellpadding="0" ALIGN="left">
						<xsl:apply-templates select="TO"/>
					</TABLE>
				</TD></TR>

				<TR><TD><xsl:text>　</xsl:text></TD></TR>
				<TR><TD><xsl:text>　</xsl:text></TD></TR>

				<TR><TD>
					<TABLE border="0" cellspacing="0" cellpadding="0" ALIGN="RIGHT">
						<xsl:apply-templates select="AUTHOR"/>
					</TABLE>
				</TD></TR>

				<TR><TD><xsl:text>　</xsl:text></TD></TR>
				<TR><TD><xsl:text>　</xsl:text></TD></TR>

				<TR><TD>
					<TABLE border="0" cellspacing="0" cellpadding="0" ALIGN="LEFT">
						<TR><TD>
							<xsl:text>　</xsl:text>
							<xsl:text>　</xsl:text>
							<xsl:text>　</xsl:text>
							<xsl:value-of select="TITLE"/>
						</TD></TR>
						<TR><TD>
							<xsl:value-of select="MAINTXT"/>
						</TD></TR>
						<TR><TD>
							<xsl:apply-templates select="MAINTXT2"/>
						</TD></TR>
						<TR><TD>
							<xsl:apply-templates select="REFERENC"/>
						</TD></TR>
					</TABLE>
				</TD></TR>
			</TABLE>
		</PRE>
	</BODY>
</HTML>
</xsl:template>

<xsl:template match="TO" >
	    <TR><TD>
	        <xsl:text>　</xsl:text>
	        <xsl:if test="AFF!=''">
		        <xsl:value-of select="AFF" />
	        </xsl:if>
	        <xsl:text>　</xsl:text>
	        <xsl:if test="NAME!=''">
		        <xsl:value-of select="NAME" />
		            <xsl:if test="HONORIFC!=''">
						<xsl:text>　</xsl:text>
			            <xsl:value-of select="HONORIFC" />
		            </xsl:if>
	        </xsl:if>
	    </TD></TR>
</xsl:template>

<xsl:template match="AUTHOR" >
		<TR><TD>
                <xsl:value-of select="AFF" />
			    <xsl:text>　</xsl:text>
	            <xsl:if test="NAME!=''">
		            <xsl:value-of select="NAME" />
		        </xsl:if>
		    </TD>
		    <TD><xsl:text>　</xsl:text></TD>
		    <TD><xsl:text>　</xsl:text></TD>
		    <TD><xsl:text>　</xsl:text></TD>
		</TR>
</xsl:template>

<xsl:template match="MAINTXT2">
	<TABLE border="0" cellspacing="0" cellpadding="0"  width="580">
		<TR><TD><xsl:text>　</xsl:text></TD></TR>
		<TR><TD align="center">
				<xsl:apply-templates select="MT2TITLE"/>
		</TD></TR>
		<TR><TD><xsl:text>　</xsl:text></TD></TR>
		<TR><TD align="left">
			<xsl:value-of select="MT2TEXT"/>
		</TD></TR>
	</TABLE>
</xsl:template>

<xsl:template match="MT2TITLE">
	<xsl:value-of select="."/>
</xsl:template>

<xsl:template match="MT2TEXT">
	<xsl:apply-templates />
</xsl:template>

<xsl:template match="P">
	<xsl:copy-of select="."/>
</xsl:template>

</xsl:stylesheet>
